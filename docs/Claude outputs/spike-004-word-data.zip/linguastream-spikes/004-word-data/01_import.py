"""Check 1 (+ 9): import the German Wiktextract data and FrequencyWords into Postgres.

Usage: python 01_import.py <kaikki German .jsonl or .jsonl.gz> [--freq de_50k.txt]
Writes out/import.md with sizes, times, memory and what the parser found.
"""
import gzip, json, os, re, sys, time
from pathlib import Path
import psutil
from common import db, OUT, HERE

args = sys.argv[1:]
freq_path = None
if "--freq" in args:
    k = args.index("--freq"); freq_path = args[k + 1]; del args[k:k + 2]
if not args:
    sys.exit(__doc__)
src = Path(args[0])

SKIP_FORM_TAGS = {"table-tags", "inflection-template", "class", "romanization", "error-unknown-tag"}
proc = psutil.Process()
peak = 0


def mem():
    global peak
    peak = max(peak, proc.memory_info().rss)


def categories(e):
    out = []
    for c in e.get("categories", []) + [c for s in e.get("senses", []) for c in s.get("categories", [])]:
        out.append(c.get("name", "") if isinstance(c, dict) else str(c))
    return out


def gender_of(e):
    """m / f / n from top-level tags, sense tags or the headword line ("Hund m (strong, …)")."""
    tags = set(e.get("tags", [])) | {t for s in e.get("senses", []) for t in s.get("tags", [])}
    found = [g for g, t in (("m", "masculine"), ("f", "feminine"), ("n", "neuter")) if t in tags]
    if not found:
        for h in e.get("head_templates", []):
            m = re.match(r"^\S+(?:\s\S+)*?\s(m|f|n)(?:\s|,|$|\()", h.get("expansion", ""))
            if m:
                found = [m.group(1)]; break
    return ",".join(sorted(set(found))) or None


def plural_of(e):
    for f in e.get("forms", []):
        t = set(f.get("tags", []))
        if "plural" in t and ("nominative" in t or t == {"plural"}) and not t & SKIP_FORM_TAGS:
            return f.get("form")
    return None


def flags_of(e, pos):
    flags = set()
    cats = " | ".join(categories(e)).lower()
    if pos == "verb":
        if re.search(r"(?<!in)separable verbs", cats):
            flags.add("separable")
        if "using sein as auxiliary" in cats or "sein as auxiliary" in cats:
            flags.add("aux-sein")
        if any("reflexive" in s.get("tags", []) for s in e.get("senses", [])):
            flags.add("reflexive")
    return sorted(flags)


def senses_of(e):
    out = []
    for s in e.get("senses", []):
        if s.get("form_of") or s.get("alt_of"):
            continue
        gl = s.get("glosses") or s.get("raw_glosses")
        if not gl:
            continue
        ex = next((x for x in s.get("examples", []) if x.get("text")), None)
        out.append({
            "gloss": gl[-1],                 # the most specific gloss of a nested sense
            "glosses": gl,
            "tags": s.get("tags", []),
            "example": ex.get("text") if ex else None,
            "example_en": (ex.get("english") or ex.get("translation")) if ex else None,
        })
    return out


stats = {k: 0 for k in ["lines", "german", "entries", "form_of_entries", "forms", "noun", "noun_gender", "noun_plural",
                        "verb", "separable", "reflexive", "aux_sein", "no_senses_no_form_of"]}
t0 = time.time()
opener = gzip.open if src.suffix == ".gz" else open
conn = db()
conn.execute((HERE / "schema.sql").read_text())
with conn.cursor() as cur, \
        cur.copy("COPY entry (word, pos, gender, plural, flags, senses, sense_count) FROM STDIN") as ce:
    pending_forms = []
    with opener(src, "rt", encoding="utf-8") as fh:
        for line in fh:
            stats["lines"] += 1
            if stats["lines"] % 50000 == 0:
                mem(); print(f"{stats['lines']:,} lines, {time.time() - t0:.0f} s", flush=True)
            e = json.loads(line)
            if e.get("lang_code") != "de":
                continue
            stats["german"] += 1
            word, pos = e.get("word"), e.get("pos", "")
            if not word:
                continue
            senses = senses_of(e)
            bases = {f.get("word") for s in e.get("senses", []) for f in (s.get("form_of") or []) if f.get("word")}
            forms = {(word, word, pos, ())}
            for b in bases:
                forms.add((word, b, pos, ("form-of",)))
            if senses:
                stats["entries"] += 1
                g = gender_of(e) if pos == "noun" else None
                pl = plural_of(e) if pos == "noun" else None
                fl = flags_of(e, pos)
                if pos == "noun":
                    stats["noun"] += 1; stats["noun_gender"] += bool(g); stats["noun_plural"] += bool(pl)
                if pos == "verb":
                    stats["verb"] += 1
                    stats["separable"] += "separable" in fl; stats["reflexive"] += "reflexive" in fl; stats["aux_sein"] += "aux-sein" in fl
                ce.write_row((word, pos, g, pl, fl, json.dumps(senses, ensure_ascii=False), len(senses)))
                for f in e.get("forms", []):
                    t = tuple(f.get("tags", []))
                    fw = f.get("form", "")
                    if fw and fw not in ("-", "—") and not set(t) & SKIP_FORM_TAGS:
                        forms.add((fw, word, pos, t))
            elif bases:
                stats["form_of_entries"] += 1
            else:
                stats["no_senses_no_form_of"] += 1
            stats["forms"] += len(forms)
            pending_forms.extend(forms)
mem()
t_entries = time.time() - t0
with conn.cursor() as cur, cur.copy("COPY form (form, lemma, pos, tags) FROM STDIN") as cf:
    for f, l, p, t in pending_forms:
        cf.write_row((f, l, p, list(t)))
mem()
del pending_forms

freq_note = "not imported (no --freq file)"
if freq_path:
    with conn.cursor() as cur, cur.copy("COPY freq (word, count, rank) FROM STDIN") as cq:
        seen = set()
        rank = 0
        for line in open(freq_path, encoding="utf-8"):
            parts = line.split()
            if len(parts) == 2 and parts[0] not in seen:
                seen.add(parts[0]); rank += 1
                cq.write_row((parts[0], int(parts[1]), rank))
    freq_note = f"{rank:,} words imported"

t_idx = time.time()
conn.execute((HERE / "indexes.sql").read_text())
conn.commit()
t_end = time.time()


def size(rel):
    return conn.execute("SELECT pg_size_pretty(pg_total_relation_size(%s))", (rel,)).fetchone()[0]


db_size = conn.execute("SELECT pg_size_pretty(pg_database_size(current_database()))").fetchone()[0]
pct = lambda a, b: f"{100 * a / b:.0f}%" if b else "–"
md = f"""# Check 1: import

Source: `{src.name}` ({src.stat().st_size / 1e6:.0f} MB on disk). FrequencyWords: {freq_note}.

| | |
|---|---|
| Lines read / German entries | {stats['lines']:,} / {stats['german']:,} |
| Entries with senses (lemmas) | {stats['entries']:,} |
| "Form of" entries (inflected forms only) | {stats['form_of_entries']:,} |
| Entries with neither | {stats['no_senses_no_form_of']:,} |
| Form index rows | {stats['forms']:,} |
| Nouns / with gender / with plural | {stats['noun']:,} / {stats['noun_gender']:,} ({pct(stats['noun_gender'], stats['noun'])}) / {stats['noun_plural']:,} ({pct(stats['noun_plural'], stats['noun'])}) |
| Verbs / separable / reflexive senses / sein as auxiliary | {stats['verb']:,} / {stats['separable']:,} / {stats['reflexive']:,} / {stats['aux_sein']:,} |
| Time: parse + load entries / load forms / indexes / total | {t_entries:.0f} s / {t_idx - t_entries - t0:.0f} s / {t_end - t_idx:.0f} s / {t_end - t0:.0f} s |
| Peak memory of the import script | {peak / 1e6:.0f} MB |
| Postgres: entry / form / freq / whole database | {size('entry')} / {size('form')} / {size('freq')} / {db_size} |
"""
(OUT / "import.md").write_text(md, encoding="utf-8")
print(md)
