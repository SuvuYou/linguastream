"""Check 8 (D-060, D-065): Ukrainian glosses translated from the English ones, with context.

Usage: python 04_ukrainian.py [out/packs/<video>.json] [--batch 50] [--mock]
Default: the smallest word pack. Writes out/ukrainian-check.md for a Ukrainian speaker to mark.
"""
import json, os, sys
from pathlib import Path
from common import OUT, db
import gemini

args = sys.argv[1:]
batch = int(args[args.index("--batch") + 1]) if "--batch" in args else 50
if "--mock" in args:
    os.environ["GEMINI_MOCK"] = "1"
files = [a for a in args if a.endswith(".json")]
pack_path = Path(files[0]) if files else min((OUT / "packs").glob("*.json"), key=lambda p: p.stat().st_size)
pack = json.loads(pack_path.read_text(encoding="utf-8"))
items = [(l, v) for l, v in pack.items() if v.get("gloss")]

# an example sentence from the dictionary, as D-065's context
conn = db()
ex = dict(conn.execute("SELECT word, senses->0->>'example' FROM entry WHERE word = ANY(%s)", ([l for l, _ in items],)).fetchall())

SYSTEM = ("Translate short English dictionary glosses of German words into Ukrainian. Each item has the German word, "
          "its part of speech, the English gloss and maybe a German example. Translate the meaning the English gloss "
          "gives for this German word, as a short dictionary-style gloss (one to four words), not a sentence.")
SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "i": {"type": "integer"}, "uk": {"type": "string"}}, "required": ["i", "uk"]}}}, "required": ["items"]}

out = {}
for start in range(0, len(items), batch):
    chunk = items[start:start + batch]
    lines = [{"i": start + k, "word": l, "pos": v["pos"], "gloss": v["gloss"], "example": ex.get(l)} for k, (l, v) in enumerate(chunk)]
    r = gemini.ask(SYSTEM, json.dumps(lines, ensure_ascii=False), SCHEMA,
                   mock=lambda u: {"items": [{"i": x["i"], "uk": "(uk) " + x["gloss"]} for x in json.loads(u)]})
    for it in (r or {}).get("items", []):
        out[it["i"]] = it["uk"]
    print(f"{min(start + batch, len(items))}/{len(items)}", flush=True)

u = gemini.usage
md = [f"# Check 8: Ukrainian glosses for `{pack_path.name}`\n",
      f"{len(items)} glosses, {len(out)} translated. Calls {u['calls']}, errors {u['errors']}, tokens in/out {u['in']:,}/{u['out']:,}, "
      f"cost ${gemini.cost():.4f}.\n",
      "Mark the first 50: good / wrong / awkward.\n", "| # | German | POS | English gloss | Ukrainian | Mark |", "|---|---|---|---|---|---|"]
md += [f"| {i} | {l} | {v['pos']} | {v['gloss']} | {out.get(i, '–')} | |" for i, (l, v) in enumerate(items)]
(OUT / "ukrainian-check.md").write_text("\n".join(md) + "\n", encoding="utf-8")
print("\n".join(md[:3]))
