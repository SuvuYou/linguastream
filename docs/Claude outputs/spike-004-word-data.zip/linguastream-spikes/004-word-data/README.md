# Spike 004 – word data

Code for `docs/changes/004-word-data-spike/spec.md` (D-083). Record results in `docs/changes/004-word-data-spike/results.md`.

| Script | Checks |
|---|---|
| `01_import.py` | 1 import (size, time, memory, what the parser found), 9 frequency import |
| `02_analyze.py` | 2 coverage, 3 form index, 4 glosses, 5 badges, 6 word packs, 9 frequency ranks, F-14 join rule with the Wiktextract verb check (D-081) |
| `03_senses.py` | 7 sense in context with Gemini vs "first sense" (Q-34) |
| `04_ukrainian.py` | 8 Ukrainian glosses from the English ones (D-060, D-065) |

`02_analyze.py` runs the D-081 order: join rule (verb check from the form index) → spaCy on the normalised text. It also joins **separable verbs** ("fangen … an" → "anfangen") using spaCy's `svp` dependency label, and falls back to the form index when spaCy's lemma isn't a dictionary word.

## Setup (PowerShell, in this folder)
1. **Postgres:** `docker compose up -d` (Postgres 17 on port 5434, data in a Docker volume).
2. **Python:**
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python -m spacy download de_core_news_sm
   copy .env.example .env      # add your Gemini key for checks 7–8
   ```
3. **Data** into a `data` folder here (ignored by git):
   - Wiktextract German: on **kaikki.org → German** ("dictionary/German"), the link for the **JSONL data of all word senses** in the German dictionary. Either the `.jsonl` or the `.jsonl.gz` works; the gzip is smaller and is read directly.
   - FrequencyWords German: `de_50k.txt` from the **hermitdave/FrequencyWords** repository on GitHub (`content/2018/de/`).
4. **Caption files:** the scripts read `../002-punctuation/input` by default; add the extra videos from F-13 there, or pass another folder.

## Runs
| Step | Command | Output to read or mark |
|---|---|---|
| 1 | `python 01_import.py data\kaikki.org-dictionary-German.jsonl.gz --freq data\de_50k.txt` (takes minutes; note the time) | `out/import.md` |
| 2 | `python 02_analyze.py` | `out/analyze.md`; mark `out/forms-check.md`, `out/glosses-check.md`, `out/badges-check.md`, `out/joins-check.md` |
| 3 | `python 03_senses.py --mock` (dry run), then `python 03_senses.py` | mark `out/senses-check.md` |
| 4 | `python 04_ukrainian.py --mock`, then `python 04_ukrainian.py` | a Ukrainian speaker marks `out/ukrainian-check.md` |

Use the real file name of the download in step 1.

## Notes
- **Licences:** Wiktionary text (and so Wiktextract) is CC BY-SA, which needs attribution wherever glosses are shown; check FrequencyWords' licence in its repository. Both go on the attributions list (`docs/roadmap/before-demo.md`).
- **Memory:** the import keeps the form index in memory until it loads it; `out/import.md` reports the peak. That number feeds the server size (Q-30).
- **Free tier:** checks 7–8 make about 50 and 1–5 calls. Rate-limit errors wait 30 s and retry once.
