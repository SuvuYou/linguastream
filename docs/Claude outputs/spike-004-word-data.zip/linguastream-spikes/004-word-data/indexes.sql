CREATE INDEX entry_word ON entry (word);
CREATE INDEX entry_word_lower ON entry (lower(word));
CREATE INDEX form_form ON form (form);
CREATE INDEX form_form_lower ON form (lower(form));
ANALYZE;
