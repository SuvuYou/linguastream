"""Small wrapper around the Gemini API for checks 7 and 8."""
import json, os, time
from google import genai
from google.genai import types

MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite")
PRICE_IN = float(os.environ.get("PRICE_IN", "0.25"))
PRICE_OUT = float(os.environ.get("PRICE_OUT", "1.50"))
_client = None
usage = {"in": 0, "out": 0, "calls": 0, "errors": 0}


def ask(system, user, schema=None, mock=None):
    """One call; returns parsed JSON (if schema) or text. mock=a function for dry runs."""
    if os.environ.get("GEMINI_MOCK") == "1":
        return mock(user) if mock else ""
    global _client
    if _client is None:
        if not os.environ.get("GEMINI_API_KEY"):
            raise SystemExit("GEMINI_API_KEY missing: put it in .env (or use --mock)")
        _client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    cfg = types.GenerateContentConfig(
        system_instruction=system, temperature=0,
        thinking_config=types.ThinkingConfig(thinking_level="MINIMAL"),
        http_options=types.HttpOptions(timeout=90_000),
        **({"response_mime_type": "application/json", "response_schema": schema} if schema else {}))
    for attempt in range(2):
        try:
            r = _client.models.generate_content(model=MODEL, contents=user, config=cfg)
            u = r.usage_metadata
            usage["in"] += u.prompt_token_count or 0
            usage["out"] += (u.candidates_token_count or 0) + (u.thoughts_token_count or 0)
            usage["calls"] += 1
            return json.loads(r.text) if schema else r.text
        except Exception as e:  # rate limits on the free tier: wait and retry once
            usage["errors"] += 1
            print("  API error:", str(e)[:150], flush=True)
            time.sleep(30 if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e) else 5)
    return None


def cost():
    return (usage["in"] * PRICE_IN + usage["out"] * PRICE_OUT) / 1e6
