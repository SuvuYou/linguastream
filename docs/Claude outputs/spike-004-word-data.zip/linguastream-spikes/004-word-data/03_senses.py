"""Check 7 (Q-34): Gemini picks a word's meaning in context. Compare with "first sense".

Usage: python 03_senses.py [--n 50] [--mock]
Needs out/occurrences.jsonl from 02_analyze.py. Writes out/senses-check.md to mark.
"""
import json, random, sys, os
from common import OUT
import gemini

args = sys.argv[1:]
n = int(args[args.index("--n") + 1]) if "--n" in args else 50
if "--mock" in args:
    os.environ["GEMINI_MOCK"] = "1"
random.seed(7)

occ = [json.loads(l) for l in open(OUT / "occurrences.jsonl", encoding="utf-8")]
# one occurrence per lemma, at most 10 senses listed
by_lemma = {}
for o in occ:
    by_lemma.setdefault((o["lemma"], o["pos"]), o)
sample = random.sample(list(by_lemma.values()), min(n, len(by_lemma)))

SYSTEM = ("Du bekommst einen deutschen Satz aus einem Video, ein Wort daraus und die nummerierten Bedeutungen dieses Wortes "
          "aus einem Wörterbuch (auf Englisch). Wähle die Bedeutung, die im Satz gemeint ist. "
          "Wenn keine passt, antworte mit 0.")
SCHEMA = {"type": "object", "properties": {"sense": {"type": "integer"}}, "required": ["sense"]}

md = ["# Check 7: sense in context (Q-34)\n",
      "For each word: which meaning is right? Mark **G** if Gemini's pick is right, **F** if the first sense is right, "
      "**both**, or **neither** (then the dictionary lacks the meaning).\n"]
same = 0
for k, o in enumerate(sample, 1):
    senses = o["senses"][:10]
    listing = "\n".join(f"{i}. {g}" for i, g in enumerate(senses, 1))
    user = f"Satz: {o['sentence']}\nWort: {o['word']} (Grundform: {o['lemma']})\n\nBedeutungen:\n{listing}"
    r = gemini.ask(SYSTEM, user, SCHEMA, mock=lambda u: {"sense": 1 + (len(u) % len(senses))})
    pick = r["sense"] if r else None
    same += pick == 1
    md.append(f"\n## {k}. {o['word']} ({o['lemma']}, {o['pos']})\n\n> {o['sentence']}\n")
    md.extend(f"- {'**→ Gemini**' if i == pick else ''}{' (first)' if i == 1 else ''} {i}. {g}" for i, g in enumerate(senses, 1))
    md.append(f"- Gemini: {pick if pick is not None else 'error'}{' (none fits)' if pick == 0 else ''}  — Mark: ")
    print(f"{k}/{len(sample)} {o['lemma']}: {pick}", flush=True)

u = gemini.usage
head = (f"\n**{len(sample)} words, Gemini picked the first sense {same} times.** Calls {u['calls']}, errors {u['errors']}, "
        f"tokens in/out {u['in']:,}/{u['out']:,}, cost ${gemini.cost():.4f} (${gemini.cost() / max(1, u['calls']):.6f} per pick).\n")
md.insert(2, head)
(OUT / "senses-check.md").write_text("\n".join(md) + "\n", encoding="utf-8")
print(head)
