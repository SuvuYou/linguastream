-- Only what the popups and word packs need (D-056, D-058). Rebuilt by 01_import.py.
DROP TABLE IF EXISTS entry, form, freq;

-- One row per Wiktextract entry that has real senses (not just "form of").
CREATE TABLE entry (
  id          serial PRIMARY KEY,
  word        text NOT NULL,          -- lemma as written: "Hund", "anfangen"
  pos         text NOT NULL,          -- noun, verb, adj, adv, ...
  gender      text,                   -- m / f / n for nouns
  plural      text,                   -- nominative plural for nouns
  flags       text[] NOT NULL DEFAULT '{}',  -- separable, reflexive, aux-sein, ...
  senses      jsonb NOT NULL,         -- [{gloss, glosses, tags, example, example_en}]
  sense_count int NOT NULL
);

-- Every written form → its lemma and part of speech (D-081: form lookup).
CREATE TABLE form (
  form   text NOT NULL,
  lemma  text NOT NULL,
  pos    text NOT NULL,
  tags   text[] NOT NULL DEFAULT '{}'
);

-- FrequencyWords (OpenSubtitles) counts per written form.
CREATE TABLE freq (
  word  text PRIMARY KEY,
  count bigint NOT NULL,
  rank  int NOT NULL
);
