"""Shared helpers: settings, database, caption files, the join rule (D-077/078/081)."""
import json, os, re, sys
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE / "out"
OUT.mkdir(exist_ok=True)


def load_env():
    """Read .env (KEY=value lines) into os.environ, without overriding real env vars."""
    p = HERE / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


load_env()


def db():
    import psycopg
    return psycopg.connect(os.environ.get("DATABASE_URL", "postgresql://postgres:spike@localhost:5434/words"))


# ---------- caption files (same logic as spike 002's extract.ts) ----------

def caption_files(args):
    """Files from arguments (files or folders); default: spike 002's input folder."""
    paths = args or [str(HERE.parent / "002-punctuation" / "input")]
    files = []
    for a in paths:
        p = Path(a)
        files += sorted(p.glob("*.json")) if p.is_dir() else [p]
    if not files:
        sys.exit("No caption files. Put the json3 files from spike 002 in ../002-punctuation/input or pass a folder.")
    return files


def video_name(path):
    return re.sub(r"\.json3?\.json$|\.json$", "", Path(path).name)


def words_from_json3(path):
    """Words in order with start times; bracket tags like [Musik] and [ __ ] are dropped."""
    j = json.loads(Path(path).read_text(encoding="utf-8"))
    raw = []
    for e in j.get("events", []):
        for s in e.get("segs") or []:
            t = (e.get("tStartMs") or 0) + (s.get("tOffsetMs") or 0)
            for w in (s.get("utf8") or "").split():
                raw.append((w, t))
    out, k = [], 0
    while k < len(raw):
        w, t = raw[k]
        if w.startswith("[") and "]" not in w:          # "[" "__" "]" → one tag
            m = k + 1
            while m < len(raw) and "]" not in raw[m][0] and m - k < 8:
                m += 1
            if m < len(raw) and "]" in raw[m][0]:
                k = m + 1
                continue
        if not re.fullmatch(r"\[.*\]", w):
            out.append((w, t))
        k += 1
    return out


# ---------- the join rule (D-077, D-078, D-081) ----------

ABBREV = {"z.b.", "bzw.", "ca.", "usw.", "etc.", "d.h.", "u.a.", "o.ä.", "v.a.", "dr.", "nr.", "vs.", "evtl.", "ggf.",
          "inkl.", "mio.", "mrd.", "std.", "min.", "max.", "jh.", "str.", "bspw.", "sog.", "zb.", "mr.", "mrs."}
VERB_POS = {"verb", "aux", "auxiliary"}


def join_candidates(words):
    """Indices where a full stop is followed by a lowercase word (before the verb check)."""
    out = []
    for k in range(len(words) - 1):
        w, nxt = words[k], words[k + 1]
        if not re.search(r"[^.]\.$", w) or w.lower() in ABBREV:
            continue
        if re.fullmatch(r"\d+\.", w) or re.fullmatch(r"[A-Za-z]\.", w):
            continue
        if not re.match(r"[a-zäöüß]", nxt) or re.match(r"[a-zäöüß][A-ZÄÖÜ]", nxt):
            continue
        out.append(k)
    return out


def strip_punct(w):
    return re.sub(r"^[^\w]+|[^\w]+$", "", w)


def apply_joins(words, verb_forms):
    """Remove the full stop before a lowercase word unless Wiktextract says it can be a verb."""
    joined, kept = [], []
    out = list(words)
    for k in join_candidates(words):
        nxt = strip_punct(words[k + 1]).lower()
        if nxt in verb_forms:
            kept.append(k)
        else:
            out[k] = words[k][:-1]
            joined.append(k)
    return out, joined, kept


def verb_form_set(conn, forms):
    """Which of these lowercase forms can be a verb or auxiliary in any entry."""
    if not forms:
        return set()
    with conn.cursor() as cur:
        cur.execute("SELECT DISTINCT lower(form) FROM form WHERE lower(form) = ANY(%s) AND pos = ANY(%s)",
                    (list(forms), list(VERB_POS)))
        return {r[0] for r in cur.fetchall()}


def sentences(words):
    """Split normalised words into sentences at . ! ? …"""
    out, cur = [], []
    for w in words:
        cur.append(w)
        if re.search(r"[.!?…][\"»«“”)]*$", w):
            out.append(" ".join(cur)); cur = []
    if cur:
        out.append(" ".join(cur))
    return out
