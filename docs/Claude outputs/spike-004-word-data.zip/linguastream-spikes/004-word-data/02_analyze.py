"""Checks 2–6 and 9 (and F-14): coverage, form index, glosses, badges, word packs, frequency, join rule.

Usage: python 02_analyze.py [caption files or folders]   (default: ../002-punctuation/input)
Needs 01_import.py first. Writes out/analyze.md plus files to mark by hand:
  out/forms-check.md, out/glosses-check.md, out/badges-check.md, out/joins-check.md
and out/occurrences.jsonl (input for 03_senses.py), out/packs/<video>.json.
"""
import collections, gzip, json, random, re, sys, time
from common import db, OUT, caption_files, video_name, words_from_json3, join_candidates, apply_joins, verb_form_set, strip_punct

import spacy

random.seed(4)
nlp = spacy.load("de_core_news_sm")
conn = db()
files = caption_files(sys.argv[1:])
(OUT / "packs").mkdir(exist_ok=True)

POS_MAP = {"NOUN": "noun", "PROPN": "name", "VERB": "verb", "AUX": "verb", "ADJ": "adj", "ADV": "adv", "ADP": "prep",
           "DET": "det", "PRON": "pron", "CCONJ": "conj", "SCONJ": "conj", "PART": "particle", "INTJ": "intj", "NUM": "num"}
SKIP_POS = {"PROPN", "NUM", "PUNCT", "SPACE", "SYM", "X"}
CONTENT = {"NOUN", "VERB", "ADJ", "ADV"}


def entries_for(lemmas):
    """All entries whose word matches any of the lemmas exactly or case-insensitively."""
    lemmas = list(lemmas)
    rows = conn.execute(
        "SELECT id, word, pos, gender, plural, flags, senses, sense_count FROM entry "
        "WHERE word = ANY(%s) OR lower(word) = ANY(%s)", (lemmas, [l.lower() for l in lemmas])).fetchall()
    by = collections.defaultdict(list)
    for r in rows:
        by[r[1]].append(r); by[r[1].lower()].append(r)
    return by


def pick_entry(by, lemma, spacy_pos):
    """Best entry: same word and part of speech, then same word, then same word ignoring case."""
    want = POS_MAP.get(spacy_pos)
    exact = by.get(lemma, [])
    for r in exact:
        if r[2] == want:
            return r
    if exact:
        return exact[0]
    for r in by.get(lemma.lower(), []):
        if r[2] == want:
            return r
    return (by.get(lemma.lower()) or [None])[0]


def forms_for(words):
    """Form index: written form → [(lemma, pos)] (exact form first, then lowercase)."""
    words = list(words)
    rows = conn.execute("SELECT form, lemma, pos FROM form WHERE form = ANY(%s) OR lower(form) = ANY(%s)",
                        (words, [w.lower() for w in words])).fetchall()
    by = collections.defaultdict(set)
    for f, l, p in rows:
        by[f].add((l, p)); by[f.lower()].add((l, p))
    return by


def short(g):
    """A popup-sized gloss: up to the first ';' or '(' ."""
    return re.split(r";|\(", g)[0].strip() if g else g


report, occ_out = [], open(OUT / "occurrences.jsonl", "w", encoding="utf-8")
lemma_freq = collections.Counter()   # (lemma, spaCy POS) over all videos
lemma_example = {}
all_tokens = []                      # (video, token text, lemma, pos, context)
joins_md = ["# F-14: join rule with the Wiktextract verb check (D-081)\n",
            "Tick = right. **joined**: the full stop was removed. **kept**: the next word can be a verb, so the full stop stayed.\n"]
rows = ["| Video | Min | Words | Joins (kept as verb) | Lemmas | Separable verbs joined | Found in Wiktextract (via form index) | Content lemmas found | Pack | Pack gzip | Pack build | Tokens known (top 2,000) |",
        "|---|---|---|---|---|---|---|---|---|---|---|---|"]
misses = collections.Counter()

for f in files:
    name = video_name(f)
    wt = words_from_json3(f)
    words = [w for w, _ in wt]
    minutes = (wt[-1][1] / 60000) if wt else 0
    # 1. join rule with the verb check, then spaCy on the normalised text (D-081 order)
    cands = join_candidates(words)
    verbs = verb_form_set(conn, {strip_punct(words[k + 1]).lower() for k in cands})
    norm, joined, kept = apply_joins(words, verbs)
    joins_md.append(f"\n## {name} ({len(joined)} joined, {len(kept)} kept)\n")
    for k in sorted(joined + kept):
        ctx_b = " ".join(words[max(0, k - 8):k + 9])
        ctx_a = " ".join(norm[max(0, k - 8):k + 9])
        joins_md.append(f"- [ ] **{'joined' if k in joined else 'kept (verb)'}** after \"{words[k]}\"\n  - before: {ctx_b}\n  - after:  {ctx_a}")
    doc = nlp(" ".join(norm))
    toks = [t for t in doc if t.is_alpha and t.pos_ not in SKIP_POS and t.dep_ != "svp"]
    # Separable verbs: spaCy's German model marks the split-off particle with dep "svp"
    # ("fangen … an" → "anfangen"), the D-052 dependency data in action.
    sep = 0
    def lemma_of(t):
        global sep
        parts = [c.text.lower() for c in t.children if c.dep_ == "svp"]
        if parts and t.pos_ in ("VERB", "AUX"):
            sep += 1
            return parts[0] + t.lemma_
        return t.lemma_
    lem = {t.i: lemma_of(t) for t in toks}
    lemmas = collections.Counter((lem[t.i], t.pos_) for t in toks)
    # 2. coverage
    by = entries_for({l for l, _ in lemmas})
    found = {lp for lp in lemmas if pick_entry(by, *lp)}
    # not found by spaCy's lemma: try the written forms through the form index
    missing_forms = {t.text for t in toks if (lem[t.i], t.pos_) not in found}
    fb_cov = forms_for(missing_forms)
    via_form = {(lem[t.i], t.pos_) for t in toks if (lem[t.i], t.pos_) not in found and (fb_cov.get(t.text) or fb_cov.get(t.text.lower()))}
    found |= via_form
    content = [lp for lp in lemmas if lp[1] in CONTENT]
    content_found = [lp for lp in content if lp in found]
    for lp in lemmas:
        if lp not in found:
            misses[lp] += lemmas[lp]
    # 6. word pack: lemma → pos, gender, short gloss
    tb = time.time()
    pack = {}
    for (l, p) in lemmas:
        e = pick_entry(by, l, p)
        if e:
            pack[l] = {"pos": e[2], "gender": e[3], "gloss": short(e[6][0]["gloss"]) if e[6] else None}
    raw = json.dumps(pack, ensure_ascii=False).encode()
    (OUT / "packs" / f"{name}.json").write_bytes(raw)
    t_pack = time.time() - tb
    # coverage score demo: tokens whose lemma is among the 2,000 most frequent (filled after freq ranks below)
    lemma_freq.update(lemmas)
    for t in toks:
        lemma_example.setdefault((lem[t.i], t.pos_), t.sent.text.strip())
        all_tokens.append((name, t.text, lem[t.i], t.pos_, t.sent.text.strip()))
        e = pick_entry(by, lem[t.i], t.pos_)
        if e and e[7] >= 2 and t.pos_ in {"NOUN", "VERB", "ADJ"}:
            occ_out.write(json.dumps({"video": name, "sentence": t.sent.text.strip(), "word": t.text, "lemma": lem[t.i],
                                      "pos": t.pos_, "entry_id": e[0], "senses": [s["gloss"] for s in e[6]]},
                                     ensure_ascii=False) + "\n")
    rows.append([name, f"{minutes:.1f}", len(words), f"{len(joined)} ({len(kept)})", len(lemmas),
                 sep, f"{len(found)} ({100 * len(found) / max(1, len(lemmas)):.0f}%; {len(via_form)} via forms)",
                 f"{len(content_found)}/{len(content)} ({100 * len(content_found) / max(1, len(content)):.0f}%)",
                 f"{len(raw) / 1024:.0f} KB", f"{len(gzip.compress(raw)) / 1024:.0f} KB", f"{t_pack * 1000:.0f} ms", lemmas])
    print(f"{name}: {len(lemmas)} lemmas, {len(found)} found", flush=True)
occ_out.close()

# 9. frequency rank per lemma: sum FrequencyWords counts over all forms of the lemma
have_freq = conn.execute("SELECT count(*) FROM freq").fetchone()[0] > 0
rank = {}
if have_freq:
    top = [l for (l, p), _ in lemma_freq.most_common()]
    res = conn.execute("""SELECT f.lemma, sum(q.count) FROM form f JOIN freq q ON q.word = lower(f.form)
                          WHERE f.lemma = ANY(%s) GROUP BY f.lemma""", (top,)).fetchall()
    all_counts = conn.execute("""SELECT f.lemma, sum(q.count) c FROM form f JOIN freq q ON q.word = lower(f.form)
                                 GROUP BY f.lemma ORDER BY c DESC LIMIT 20000""").fetchall()
    rank = {l: i + 1 for i, (l, _) in enumerate(all_counts)}
known = {l for l, r in rank.items() if r <= 2000}
for r in rows[2:]:
    lem = r[-1]
    tot = sum(lem.values())
    kn = sum(c for (l, p), c in lem.items() if l in known)
    r[-1] = f"{100 * kn / max(1, tot):.0f}%" if have_freq else "no freq"
rows = rows[:2] + ["| " + " | ".join(map(str, r)) + " |" for r in rows[2:]]

# 3. form index check: 200 sampled words
sample = random.sample(all_tokens, min(200, len(all_tokens)))
fb = forms_for({t[1] for t in sample})
agree = 0
forms_md = ["# Check 3: form index (word form → lemma, POS)\n", "Mark the last column: right / wrong / missing. \"Agrees\" = spaCy's lemma is among the form index candidates.\n",
            "| Word | Context | spaCy | Form index | Agrees | Right? |", "|---|---|---|---|---|---|"]
verb_readings = 0
for v, w, l, p, s in sample:
    cands = fb.get(w) or fb.get(w.lower()) or set()
    ok = any(c[0] == l or c[0].lower() == l.lower() for c in cands)
    agree += ok
    verb_readings += any(c[1] == "verb" for c in cands) and w[:1].islower()
    ctx = s if len(s) < 120 else s[:117] + "…"
    forms_md.append(f"| {w} | {ctx} | {l} {p} | {', '.join(sorted(f'{a} {b}' for a, b in cands))[:120] or '–'} | {'yes' if ok else 'no'} | |")

# 4. glosses of the 100 most frequent content lemmas
top_content = [lp for lp, _ in lemma_freq.most_common() if lp[1] in CONTENT][:100]
by = entries_for({l for l, _ in top_content})
gl_md = ["# Check 4: glosses for the small popup\n", "Mark: good / too long / misleading / missing.\n",
         "| Lemma | POS | Senses | First gloss (short) | Full first gloss | Mark |", "|---|---|---|---|---|---|"]
gl_len = []
for l, p in top_content:
    e = pick_entry(by, l, p)
    g = e[6][0]["gloss"] if e and e[6] else None
    if g:
        gl_len.append(len(short(g)))
    gl_md.append(f"| {l} | {p} | {e[7] if e else 0} | {short(g) or '–'} | {(g or '–')[:100]} | |")

# 5. badges: 50 frequent nouns and 50 frequent verbs
nouns = [lp for lp, _ in lemma_freq.most_common() if lp[1] == "NOUN"][:50]
verbs_ = [lp for lp, _ in lemma_freq.most_common() if lp[1] == "VERB"][:50]
by = entries_for({l for l, _ in nouns + verbs_})
bd_md = ["# Check 5: badges\n", "Mark: right / wrong / missing.\n", "| Lemma | POS | Gender | Plural | Flags | Mark |", "|---|---|---|---|---|---|"]
n_g = n_pl = 0
for l, p in nouns + verbs_:
    e = pick_entry(by, l, p)
    if e and p == "NOUN":
        n_g += bool(e[3]); n_pl += bool(e[4])
    bd_md.append(f"| {l} | {p} | {e[3] if e else '–'} | {e[4] if e else '–'} | {', '.join(e[5]) if e and e[5] else ''} | |")

# summary
gl_len.sort()
med = gl_len[len(gl_len) // 2] if gl_len else 0
md = "\n".join(["# Checks 2–6, 9: word data on the caption files\n", *rows, "",
                f"**Form index (check 3):** spaCy's lemma is among the form index candidates for {agree} of {len(sample)} sampled words; "
                f"{verb_readings} lowercase sampled words have a verb reading. Mark `out/forms-check.md`.",
                f"**Glosses (check 4):** median short gloss {med} characters; longest {gl_len[-1] if gl_len else 0}. Mark `out/glosses-check.md`.",
                f"**Badges (check 5):** of the 50 most frequent nouns, {n_g} have a gender and {n_pl} a plural. Mark `out/badges-check.md`.",
                f"**Frequency (check 9):** " + (f"{len(rank):,} lemmas ranked; 'Tokens known' assumes the 2,000 most frequent lemmas are known." if have_freq else "no FrequencyWords imported."),
                f"**Join rule (F-14):** mark `out/joins-check.md`.",
                "\n## 30 most frequent lemmas not found\n", "| Lemma | POS | Count |", "|---|---|---|",
                *[f"| {l} | {p} | {c} |" for (l, p), c in misses.most_common(30)],
                *([] if not have_freq else ["\n## Frequency spot-check: 20 random ranked lemmas\n", "| Lemma | Rank |", "|---|---|",
                                            *[f"| {l} | {rank[l]} |" for l in random.sample(sorted(rank), min(20, len(rank)))]])])
(OUT / "analyze.md").write_text(md + "\n", encoding="utf-8")
(OUT / "forms-check.md").write_text("\n".join(forms_md) + "\n", encoding="utf-8")
(OUT / "glosses-check.md").write_text("\n".join(gl_md) + "\n", encoding="utf-8")
(OUT / "badges-check.md").write_text("\n".join(bd_md) + "\n", encoding="utf-8")
(OUT / "joins-check.md").write_text("\n".join(joins_md) + "\n", encoding="utf-8")
print(md)
