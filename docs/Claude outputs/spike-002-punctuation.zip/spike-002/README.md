# Spike 002 – punctuation with word alignment

Throwaway code for `docs/changes/002-punctuation-spike/spec.md` (D-064). Outside the app repository, like the other spikes. Record results in `docs/changes/002-punctuation-spike/results.md`.

## What's here
| File | Job |
|---|---|
| `src/extract.ts` | json3 → words with start times; bracket tags (`[Musik]`, `[ __ ]`) kept as separate tokens |
| `src/align.ts` | `deriveEdits(captured, punctuated)`: the Block A exercise. Accepts only if every word is the same (ignoring case and punctuation) and returns the edit list; otherwise rejects and lists what changed |
| `src/align.test.ts` | Tests: accepted, changed, dropped, added word, free-standing dash, already punctuated |
| `src/gemini.ts` | One Gemini call: the prompt (German, "change no word"), temperature 0, thinking `MINIMAL`, optional JSON mode |
| `src/run.ts` | The command line: `inspect` (no API) and `punctuate` (chunks, overlap, one retry, reports) |
| `py/compare.py` | spaCy `de_core_news_sm` on captured vs punctuated text (check 7) |

Tags never go to the model. Each chunk is sent with 30 words of context on both sides; only the edits inside the chunk are kept. If the model changes a word, the chunk is retried once with a note listing the changes; if it fails again, that chunk stays unpunctuated.

## Setup (Windows, PowerShell)
```powershell
npm install
copy .env.example .env      # then put your key in .env
npm test                    # 7 tests, all should pass
```
For check 7 only:
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r py/requirements.txt
python -m spacy download de_core_news_sm
```

## Input
Put the 10 raw caption files from the spike extension's **Raw** button into `input/` (6 German auto, 2 uploaded German, 2 long, one with music or bleeped words; see the spec). One English example is already there; delete it or keep it for comparison.

## Runs
| Step | Command | Check |
|---|---|---|
| 1 | `npm run inspect -- input/*.json` → `out/inspect.md` | 1, 2 |
| 2 | `npm run dry-run -- input/*.json` (fake model, no key, no cost) to see the reports | – |
| 3 | `npm run punctuate -- --chunk 500 input/*.json` | 3, 6 |
| 4 | the same with `--chunk 200` and `--chunk 1000` | 4 |
| 5 | `npm run punctuate -- --chunk 500 --mode json input/*.json` | 8 |
| 6 | open `out/sample-500-text.md`, tick the correct sentences, note what's wrong in the others | 5 |
| 7 | `python py/compare.py (Get-ChildItem out/*.500.text.json).FullName` → `out/spacy-compare.md`, mark the last column | 7 |

`input/*.json` can also be written as just `input` (the folder); the script expands both itself, so it works the same in PowerShell.

## Outputs
- `out/summary-<chunk>-<mode>.md`: per video: chunks, rejected on the first try and after the retry, kinds of change, API errors, tokens (in / out / thinking), cost, time, and the cost per hour of video.
- `out/<video>.<chunk>.<mode>.json`: the words, the edit list, and every rejected change per chunk (for "which kinds of change cause rejections").
- `out/<video>.<chunk>.<mode>.txt`: the punctuated text, one sentence per line.

## Notes
- **Free tier limits:** the free tier caps requests per minute and per day. If you see API errors, use a bigger chunk or wait; the summary counts them separately.
- **Prices** in `.env` (`PRICE_IN`, `PRICE_OUT`) come from cost.md and must be checked on Google's pricing page; the free tier costs nothing, the numbers show what a paid key would cost.
- **Thinking:** Gemini 3 models think by default, which costs output tokens. `THINKING_LEVEL=MINIMAL` turns it almost off; the summary shows any thinking tokens anyway.
- Your key stays in `.env`, which `.gitignore` excludes.
