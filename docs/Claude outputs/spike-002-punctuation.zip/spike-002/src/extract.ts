// extract.ts – json3 caption file → a list of tokens with start times.
// A token is a word, or a bracket tag like "[Musik]" or "[ __ ]" (kept apart:
// tags never go to the LLM and are never punctuated).

import { readFileSync } from 'node:fs';

export interface Token {
  /** position in the full token list */
  i: number;
  /** the text exactly as captured */
  text: string;
  /** start time in ms (a word inside a multi-word segment gets the segment's time) */
  startMs: number;
  /** true for bracket tags */
  tag: boolean;
}

interface Json3 {
  events?: { tStartMs?: number; segs?: { utf8?: string; tOffsetMs?: number }[] }[];
}

/** Read a json3 file. Also accepts the spike extension's raw download. */
export function readJson3(path: string): Json3 {
  return JSON.parse(readFileSync(path, 'utf8')) as Json3;
}

export function extractTokens(j: Json3): Token[] {
  // 1. raw pieces with times
  const raw: { text: string; startMs: number }[] = [];
  for (const e of j.events ?? []) {
    if (!e.segs) continue;
    for (const s of e.segs) {
      const t = (e.tStartMs ?? 0) + (s.tOffsetMs ?? 0);
      for (const w of (s.utf8 ?? '').split(/\s+/)) if (w) raw.push({ text: w, startMs: t });
    }
  }
  // 2. merge bracket tags that span several pieces: "[" "__" "]" → "[ __ ]"
  const out: Token[] = [];
  for (let k = 0; k < raw.length; k++) {
    const r = raw[k];
    if (r.text.startsWith('[') && !r.text.includes(']')) {
      const parts = [r.text];
      let m = k + 1;
      while (m < raw.length && parts.length < 8 && !raw[m - 1].text.includes(']')) {
        parts.push(raw[m].text);
        if (raw[m].text.includes(']')) break;
        m++;
      }
      if (parts.at(-1)!.includes(']')) {
        out.push({ i: out.length, text: parts.join(' '), startMs: r.startMs, tag: true });
        k += parts.length - 1;
        continue;
      }
    }
    out.push({ i: out.length, text: r.text, startMs: r.startMs, tag: /^\[.*\]$/.test(r.text) });
  }
  return out;
}

/** Check 1: does the captured text already look punctuated? */
export function punctuationStats(tokens: Token[]) {
  const words = tokens.filter((t) => !t.tag).map((t) => t.text);
  const ends = words.filter((w) => /[.!?…]["»«“”)]*$/.test(w)).length;
  const commas = words.filter((w) => /[,;:]$/.test(w)).length;
  // after a sentence end, is the next word capitalised?
  let capAfterEnd = 0;
  for (let k = 0; k + 1 < words.length; k++) {
    if (/[.!?…]["»«“”)]*$/.test(words[k]) && /^\p{Lu}/u.test(words[k + 1])) capAfterEnd++;
  }
  return {
    words: words.length,
    sentenceEnds: ends,
    commas,
    wordsPerSentenceEnd: ends ? Math.round(words.length / ends) : null,
    capitalAfterEnd: ends ? Math.round((100 * capAfterEnd) / ends) : null,
    looksPunctuated: words.length ? ends / words.length > 0.02 : false,
  };
}

/** Check 2: which bracket tags, how often. */
export function tagStats(tokens: Token[]) {
  const counts: Record<string, number> = {};
  for (const t of tokens) if (t.tag) counts[t.text] = (counts[t.text] ?? 0) + 1;
  return counts;
}
