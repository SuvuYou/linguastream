// run.ts – the spike's command line.
//   npm run inspect -- input/*.json            checks 1–2, no API calls
//   npm run punctuate -- --chunk 500 input/*.json
// Options: --chunk N (words per chunk, default 500), --overlap N (default 30),
//          --mode text|json (default text), --no-retry, --mock (no API calls)
// Writes out/<video>.<chunk>.json (+ .txt), out/summary-<chunk>-<mode>.md and
// out/sample-<chunk>-<mode>.md (sentences to mark by hand, check 5).

import { basename, join } from 'node:path';
import { mkdirSync, writeFileSync, existsSync, statSync, readdirSync, globSync } from 'node:fs';
import { readJson3, extractTokens, punctuationStats, tagStats, type Token } from './extract.ts';
import { deriveEdits, applyEdits, sentences, type Edit, type Change } from './align.ts';
import { punctuate, MODEL, type Mode } from './gemini.ts';

const args = process.argv.slice(2);
const cmd = args.shift();
const opt = (name: string, def: string) => {
  const k = args.indexOf('--' + name);
  if (k < 0) return def;
  const v = args[k + 1];
  args.splice(k, 2);
  return v;
};
const flag = (name: string) => {
  const k = args.indexOf('--' + name);
  if (k < 0) return false;
  args.splice(k, 1);
  return true;
};
const CHUNK = Number(opt('chunk', '500'));
const OVERLAP = Number(opt('overlap', '30'));
const MODE = opt('mode', 'text') as Mode;
const RETRY = !flag('no-retry');
// --mock: no API calls, a fake model (see gemini.ts) to try the pipeline.
if (flag('mock')) process.env.GEMINI_MOCK = '1';
// Files: names, folders (all .json inside) or patterns like input/*.json
// (expanded here, because Windows shells don't expand them).
const files = args.flatMap((a) => {
  if (existsSync(a) && statSync(a).isDirectory()) return readdirSync(a).filter((f) => f.endsWith('.json')).map((f) => join(a, f));
  if (a.includes('*')) return globSync(a);
  return [a];
});
// Prices per 1M tokens (check Google's pricing page and set them in .env).
const PRICE_IN = Number(process.env.PRICE_IN ?? '0.25');
const PRICE_OUT = Number(process.env.PRICE_OUT ?? '1.50');

mkdirSync('out', { recursive: true });
const name = (f: string) => basename(f).replace(/\.json3?\.json$|\.json$/, '');
const minutes = (t: Token[]) => (t.length ? Math.round(t.at(-1)!.startMs / 600) / 100 : 0);

if (cmd === 'inspect') inspect();
else if (cmd === 'punctuate') await runAll();
else console.log('usage: npm run inspect -- files… | npm run punctuate -- [--chunk N] [--overlap N] [--mode text|json] files…');

function inspect() {
  const rows = ['| Video | Min | Words | Sentence ends | 1 end per | Capital after end | Commas | Looks punctuated | Tags |', '|---|---|---|---|---|---|---|---|---|'];
  for (const f of files) {
    const t = extractTokens(readJson3(f));
    const s = punctuationStats(t);
    const tags = Object.entries(tagStats(t)).map(([k, v]) => `${k}×${v}`).join(' ');
    rows.push(`| ${name(f)} | ${minutes(t)} | ${s.words} | ${s.sentenceEnds} | ${s.wordsPerSentenceEnd ?? '–'} | ${s.capitalAfterEnd ?? '–'}% | ${s.commas} | ${s.looksPunctuated ? 'yes' : 'no'} | ${tags} |`);
  }
  const md = '# Checks 1–2: captions as captured\n\n' + rows.join('\n') + '\n';
  writeFileSync('out/inspect.md', md);
  console.log(md);
}

interface ChunkReport {
  start: number; end: number; ok: boolean; retried: boolean;
  changes: Change[]; errors: string[]; tokensIn: number; tokensOut: number; tokensThinking: number; ms: number;
}

async function runAll() {
  const rows = ['| Video | Min | Words | Chunks | Rejected 1st try | Rejected after retry | Changes (kinds) | API errors | Tokens in / out / thinking | Cost | Time |', '|---|---|---|---|---|---|---|---|---|---|---|'];
  const sample: string[] = [`# Check 5: mark each sentence\n\nChunk ${CHUNK}, overlap ${OVERLAP}, mode ${MODE}, model ${MODEL}. Tick = correct; otherwise note: wrong boundary / missing comma / wrong capital.\n`];
  let totIn = 0, totOut = 0, totMin = 0;
  for (const f of files) {
    const r = await runOne(f);
    const rej1 = r.chunks.filter((c) => !c.ok || c.retried).length;
    const rej2 = r.chunks.filter((c) => !c.ok).length;
    const kinds: Record<string, number> = {};
    for (const c of r.chunks) for (const ch of c.changes) kinds[ch.kind] = (kinds[ch.kind] ?? 0) + 1;
    const tin = sum(r.chunks.map((c) => c.tokensIn)), tout = sum(r.chunks.map((c) => c.tokensOut)), tthink = sum(r.chunks.map((c) => c.tokensThinking));
    const cost = (tin * PRICE_IN + (tout + tthink) * PRICE_OUT) / 1e6;
    totIn += tin; totOut += tout + tthink; totMin += r.min;
    rows.push(`| ${r.name} | ${r.min} | ${r.words} | ${r.chunks.length} | ${rej1} | ${rej2} | ${Object.entries(kinds).map(([k, v]) => `${k} ${v}`).join(', ') || '–'} | ${sum(r.chunks.map((c) => c.errors.length))} | ${tin} / ${tout} / ${tthink} | $${cost.toFixed(4)} | ${(sum(r.chunks.map((c) => c.ms)) / 1000).toFixed(1)} s |`);
    // 10 sentences from the middle of the video, for manual marking
    const s = r.sentences.filter((x) => x.split(' ').length > 3);
    const from = Math.max(0, Math.floor(s.length / 2) - 5);
    sample.push(`\n## ${r.name}\n` + s.slice(from, from + 10).map((x) => `- [ ] ${x}`).join('\n'));
  }
  const perHour = totMin ? ((totIn * PRICE_IN + totOut * PRICE_OUT) / 1e6) * (60 / totMin) : 0;
  const md = `# Punctuation run: chunk ${CHUNK}, overlap ${OVERLAP}, mode ${MODE}\n\nModel ${MODEL}, prices $${PRICE_IN} / $${PRICE_OUT} per 1M tokens (in / out incl. thinking).\n\n` +
    rows.join('\n') + `\n\n**Cost per hour of video:** $${perHour.toFixed(4)} (over ${totMin.toFixed(1)} min).\n\nRejection details per chunk: \`out/<video>.${CHUNK}.${MODE}.json\`.\n`;
  writeFileSync(`out/summary-${CHUNK}-${MODE}.md`, md);
  writeFileSync(`out/sample-${CHUNK}-${MODE}.md`, sample.join('\n') + '\n');
  console.log(md);
}

async function runOne(file: string) {
  const tokens = extractTokens(readJson3(file));
  // Tags never go to the LLM; they keep their place in `tokens` (check 2).
  const words = tokens.filter((t) => !t.tag);
  const texts = words.map((t) => t.text);
  const edits: Edit[] = [];
  const chunks: ChunkReport[] = [];
  for (let start = 0; start < texts.length; start += CHUNK) {
    const end = Math.min(texts.length, start + CHUNK);
    // send overlap words on both sides for context; keep edits for [start, end) only
    const from = Math.max(0, start - OVERLAP), to = Math.min(texts.length, end + OVERLAP);
    const slice = texts.slice(from, to);
    const rep: ChunkReport = { start, end, ok: false, retried: false, changes: [], errors: [], tokensIn: 0, tokensOut: 0, tokensThinking: 0, ms: 0 };
    let note: string | undefined;
    for (let attempt = 0; attempt < (RETRY ? 2 : 1); attempt++) {
      let res;
      try {
        res = await punctuate(slice, MODE, note);
      } catch (e) {
        rep.errors.push(String((e as Error).message).slice(0, 300));
        await sleep(5000);
        continue;
      }
      rep.tokensIn += res.tokensIn; rep.tokensOut += res.tokensOut; rep.tokensThinking += res.tokensThinking; rep.ms += res.ms;
      const d = deriveEdits(slice, res.text);
      if (d.ok) {
        for (const e of d.edits) {
          const gi = from + e.i;
          if (gi >= start && gi < end) edits.push({ ...e, i: gi });
        }
        rep.ok = true;
        rep.retried = attempt > 0;
        break;
      }
      rep.changes.push(...d.changes.map((c) => ('i' in c && c.i >= 0 ? { ...c, i: c.i + from } : c)));
      note = 'Achtung: In deiner letzten Antwort hast du Wörter geändert (' +
        d.changes.slice(0, 5).map((c) => c.kind === 'changed' ? `"${c.captured}" → "${c.returned}"` : c.kind === 'dropped' ? `"${c.captured}" weggelassen` : `"${c.returned}" hinzugefügt`).join(', ') +
        '). Ändere diesmal kein einziges Wort.';
    }
    chunks.push(rep);
    process.stdout.write(`${name(file)} words ${start}–${end}: ${rep.ok ? (rep.retried ? 'ok after retry' : 'ok') : rep.errors.length && !rep.changes.length ? 'API ERROR: ' + rep.errors[0] : 'REJECTED'}\n`);
  }
  const shown = applyEdits(texts, edits);
  const sents = sentences(shown, edits);
  const out = { video: name(file), model: MODEL, chunk: CHUNK, overlap: OVERLAP, mode: MODE, words: texts, edits, chunks, punctuated: shown.join(' ') };
  writeFileSync(`out/${name(file)}.${CHUNK}.${MODE}.json`, JSON.stringify(out, null, 1));
  writeFileSync(`out/${name(file)}.${CHUNK}.${MODE}.txt`, sents.join('\n') + '\n');
  return { name: name(file), min: minutes(tokens), words: texts.length, chunks, sentences: sents };
}

function sum(a: number[]) { return a.reduce((x, y) => x + y, 0); }
function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
