// align.ts – deriveEdits: compare the captured words with the LLM's punctuated
// text. Accept only if the words are the same (ignoring case and punctuation);
// then return the edit list (D-025, D-064). Otherwise reject and say what changed.

export interface Edit {
  /** index into the captured word list */
  i: number;
  /** punctuation to put before the word, e.g. „ or ( */
  before?: string;
  /** punctuation to put after the word, e.g. , or . */
  after?: string;
  /** new capitalisation of the word, when only the case differs */
  casing?: string;
  /** this word ends a sentence */
  sentenceEnd?: boolean;
}

export type Change =
  | { kind: 'changed'; i: number; captured: string; returned: string }
  | { kind: 'dropped'; i: number; captured: string }
  | { kind: 'added'; afterI: number; returned: string };

export type Result =
  | { ok: true; edits: Edit[] }
  | { ok: false; changes: Change[] };

// Punctuation that may sit before or after a word.
const LEAD = /^[„“"»«‚‘'(\[¿¡–—-]+/u;
const TRAIL = /[.,;:!?…"“”»«'’)\]–—-]+$/u;

/** Split "„Hallo," into { before: "„", core: "Hallo", after: "," }. */
export function splitToken(tok: string) {
  const before = tok.match(LEAD)?.[0] ?? '';
  let rest = tok.slice(before.length);
  const after = rest.match(TRAIL)?.[0] ?? '';
  rest = rest.slice(0, rest.length - after.length);
  return { before, core: rest, after };
}

/** What two words must share to count as "the same word". */
export const norm = (w: string) => splitToken(w).core.toLowerCase();

/** Tokens of the LLM's text; pure punctuation (e.g. " – ") is glued to the previous word. */
function returnedTokens(text: string) {
  const out: { before: string; core: string; after: string; raw: string }[] = [];
  for (const raw of text.split(/\s+/).filter(Boolean)) {
    const p = splitToken(raw);
    if (!p.core) {
      if (out.length) out[out.length - 1].after += (out[out.length - 1].after ? ' ' : '') + raw;
      continue;
    }
    out.push({ ...p, raw });
  }
  return out;
}

/**
 * Longest-common-subsequence alignment of two word lists (normalised).
 * Returns pairs [capturedIndex | -1, returnedIndex | -1] in order.
 * O(n·m) memory: fine for chunks of up to ~1,500 words.
 */
function lcsAlign(a: string[], b: string[]): [number, number][] {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let x = n - 1; x >= 0; x--) {
    for (let y = m - 1; y >= 0; y--) {
      dp[x][y] = a[x] === b[y] ? dp[x + 1][y + 1] + 1 : Math.max(dp[x + 1][y], dp[x][y + 1]);
    }
  }
  const pairs: [number, number][] = [];
  let x = 0, y = 0;
  while (x < n && y < m) {
    if (a[x] === b[y]) { pairs.push([x++, y++]); }
    else if (dp[x + 1][y] >= dp[x][y + 1]) { pairs.push([x++, -1]); }
    else { pairs.push([-1, y++]); }
  }
  while (x < n) pairs.push([x++, -1]);
  while (y < m) pairs.push([-1, y++]);
  return pairs;
}

export function deriveEdits(captured: string[], punctuated: string): Result {
  const ret = returnedTokens(punctuated);
  const a = captured.map(norm);
  const b = ret.map((t) => t.core.toLowerCase());

  // Fast path: same length and every word matches.
  const same = a.length === b.length && a.every((w, k) => w === b[k]);
  if (!same) {
    // Find out what changed, for the report.
    const pairs = lcsAlign(a, b);
    const changes: Change[] = [];
    let lastI = -1;
    for (let k = 0; k < pairs.length; k++) {
      const [x, y] = pairs[k];
      if (x >= 0 && y >= 0) { lastI = x; continue; }
      // a dropped word directly followed by an added one = a changed word
      const next = pairs[k + 1];
      if (x >= 0 && next && next[0] === -1 && next[1] >= 0) {
        changes.push({ kind: 'changed', i: x, captured: captured[x], returned: ret[next[1]].raw });
        lastI = x; k++; continue;
      }
      if (x === -1 && next && next[0] >= 0 && next[1] === -1) {
        changes.push({ kind: 'changed', i: next[0], captured: captured[next[0]], returned: ret[y].raw });
        lastI = next[0]; k++; continue;
      }
      if (x >= 0) { changes.push({ kind: 'dropped', i: x, captured: captured[x] }); lastI = x; }
      else changes.push({ kind: 'added', afterI: lastI, returned: ret[y].raw });
    }
    return { ok: false, changes };
  }

  // Same words: compare punctuation and case word by word.
  const edits: Edit[] = [];
  for (let k = 0; k < captured.length; k++) {
    const cap = splitToken(captured[k]);
    const r = ret[k];
    const e: Edit = { i: k };
    if (r.before && r.before !== cap.before) e.before = r.before;
    if (r.after !== cap.after) e.after = r.after; // may be "" = remove captured punctuation
    if (r.core !== cap.core) e.casing = r.core;
    if (/[.!?…]/.test(r.after)) e.sentenceEnd = true;
    if (Object.keys(e).length > 1) edits.push(e);
  }
  return { ok: true, edits };
}

/** Apply edits to the captured words (what the learner would see). */
export function applyEdits(captured: string[], edits: Edit[]): string[] {
  const byI = new Map(edits.map((e) => [e.i, e]));
  return captured.map((w, k) => {
    const e = byI.get(k);
    if (!e) return w;
    const p = splitToken(w);
    return (e.before ?? p.before) + (e.casing ?? p.core) + (e.after ?? p.after);
  });
}

/** Sentences (as text) from applied words, for the manual quality check. */
export function sentences(words: string[], edits: Edit[]): string[] {
  const ends = new Set(edits.filter((e) => e.sentenceEnd).map((e) => e.i));
  const out: string[] = [];
  let cur: string[] = [];
  words.forEach((w, k) => {
    cur.push(w);
    if (ends.has(k)) { out.push(cur.join(' ')); cur = []; }
  });
  if (cur.length) out.push(cur.join(' '));
  return out;
}
