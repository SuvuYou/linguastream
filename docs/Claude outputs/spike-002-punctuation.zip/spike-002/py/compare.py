"""Check 7: spaCy de_core_news_sm on raw vs punctuated text.

Usage: python py/compare.py out/<video>.500.text.json [more files] [--sample 200]
Writes out/spacy-compare.md: for sampled words, lemma and POS from both runs,
and the words where they differ, for a quick manual look.
"""
import json, random, sys
import spacy

args = sys.argv[1:]
n = 200
if "--sample" in args:
    k = args.index("--sample"); n = int(args[k + 1]); del args[k:k + 2]

nlp = spacy.load("de_core_news_sm")
random.seed(1)

def analyse(words):
    """Run spaCy on the words joined by spaces; map each word index to its first token."""
    text, starts = "", []
    for w in words:
        starts.append(len(text)); text += w + " "
    doc = nlp(text)
    by_start = {t.idx: t for t in doc}
    return [by_start.get(s) for s in starts], doc

rows, diffs, total = [], 0, 0
for path in args:
    d = json.load(open(path, encoding="utf-8"))
    raw_words = d["words"]
    punct_words = d["punctuated"].split(" ")
    if len(punct_words) != len(raw_words):
        print(f"{path}: word counts differ ({len(raw_words)} vs {len(punct_words)}), skipped"); continue
    raw_t, _ = analyse(raw_words)
    pun_t, doc = analyse(punct_words)
    idx = random.sample(range(len(raw_words)), min(n // max(1, len(args)), len(raw_words)))
    for i in sorted(idx):
        a, b = raw_t[i], pun_t[i]
        if a is None or b is None: continue
        total += 1
        same = a.lemma_.lower() == b.lemma_.lower() and a.pos_ == b.pos_
        if not same:
            diffs += 1
            ctx = " ".join(punct_words[max(0, i - 6): i + 7])
            rows.append(f"| {d['video']} | {raw_words[i]} | {a.lemma_} {a.pos_} | {b.lemma_} {b.pos_} | {ctx} | |")
    sents = list(doc.sents)
    print(f"{path}: {len(sents)} sentences by spaCy on punctuated text")

md = (f"# Check 7: spaCy on raw vs punctuated\n\n{diffs} of {total} sampled words differ in lemma or POS.\n"
      "Mark the last column: R = raw right, P = punctuated right, both wrong = X.\n\n"
      "| Video | Word | Raw: lemma POS | Punctuated: lemma POS | Context | Right? |\n|---|---|---|---|---|---|\n"
      + "\n".join(rows) + "\n")
open("out/spacy-compare.md", "w", encoding="utf-8").write(md)
print(md[:2000])
