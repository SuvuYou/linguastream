// align.ts – deriveEdits: compare the captured words with the LLM's punctuated
// text. Accept only if the words are the same (ignoring case and punctuation);
// then return the edit list (D-025, D-064). Otherwise reject, say what changed, and
// salvage the punctuation of the words that still match (D-084).

export interface Edit {
  /** index into the captured word list */
  i: number;
  /** punctuation to put before the word, e.g. „ or ( */
  before?: string;
  /** punctuation to put after the word, e.g. , or . */
  after?: string;
  /** new capitalisation of the word, when only the case differs */
  casing?: string;
  /** this word ends a sentence */
  sentenceEnd?: boolean;
  /** sentence end added by the safety net at a pause; nothing visible changes (D-084) */
  pause?: boolean;
}

export type Change =
  | { kind: 'changed'; i: number; captured: string; returned: string }
  | { kind: 'dropped'; i: number; captured: string }
  | { kind: 'added'; afterI: number; returned: string };

export type Result =
  | { ok: true; edits: Edit[] }
  | { ok: false; changes: Change[]; salvaged: Edit[] };

// Punctuation that may sit before or after a word.
const LEAD = /^[„“"»«‚‘'(\[¿¡–—-]+/u;
const TRAIL = /[.,;:!?…"“”»«'’)\]–—-]+$/u;

/** Split "„Hallo," into { before: "„", core: "Hallo", after: "," }. */
export function splitToken(tok: string) {
  const before = tok.match(LEAD)?.[0] ?? '';
  let rest = tok.slice(before.length);
  const after = rest.match(TRAIL)?.[0] ?? '';
  rest = rest.slice(0, rest.length - after.length);
  return { before, core: rest, after };
}

/** What two words must share to count as "the same word". */
export const norm = (w: string) => splitToken(w).core.toLowerCase();

/** Tokens of the LLM's text; pure punctuation (e.g. " – ") is glued to the previous word. */
function returnedTokens(text: string) {
  const out: { before: string; core: string; after: string; raw: string }[] = [];
  for (const raw of text.split(/\s+/).filter(Boolean)) {
    const p = splitToken(raw);
    if (!/[\p{L}\p{N}]/u.test(p.core)) {
      if (out.length) out[out.length - 1].after += (out[out.length - 1].after ? ' ' : '') + raw;
      continue;
    }
    out.push({ ...p, raw });
  }
  return out;
}

/**
 * Longest-common-subsequence alignment of two word lists (normalised).
 * Returns pairs [capturedIndex | -1, returnedIndex | -1] in order.
 * O(n·m) memory: fine for chunks of up to ~1,500 words.
 */
function lcsAlign(a: string[], b: string[]): [number, number][] {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let x = n - 1; x >= 0; x--) {
    for (let y = m - 1; y >= 0; y--) {
      dp[x][y] = a[x] === b[y] ? dp[x + 1][y + 1] + 1 : Math.max(dp[x + 1][y], dp[x][y + 1]);
    }
  }
  const pairs: [number, number][] = [];
  let x = 0, y = 0;
  while (x < n && y < m) {
    if (a[x] === b[y]) { pairs.push([x++, y++]); }
    else if (dp[x + 1][y] >= dp[x][y + 1]) { pairs.push([x++, -1]); }
    else { pairs.push([-1, y++]); }
  }
  while (x < n) pairs.push([x++, -1]);
  while (y < m) pairs.push([-1, y++]);
  return pairs;
}

/**
 * Captured tokens without a letter or digit (a speaker dash "-", "…", ">>") are not
 * words: they are left out of the comparison and keep their place untouched.
 * The LLM's free-standing punctuation is glued to the previous word anyway.
 */
export function deriveEdits(captured: string[], punctuated: string): Result {
  // a word has at least one letter or digit; "-", "…", ">>" (speaker change) don't
  const keep = captured.map((w, k) => (/[\p{L}\p{N}]/u.test(w) ? k : -1)).filter((k) => k >= 0);
  const r = compareWords(keep.map((k) => captured[k]), punctuated);
  const at = (i: number) => (i >= 0 ? keep[i] : i);
  if (!r.ok) {
    return {
      ok: false,
      changes: r.changes.map((c) => (c.kind === 'added' ? { ...c, afterI: at(c.afterI) } : { ...c, i: at(c.i) })),
      salvaged: r.salvaged.map((e) => ({ ...e, i: at(e.i) })),
    };
  }
  return { ok: true, edits: r.edits.map((e) => ({ ...e, i: at(e.i) })) };
}

function compareWords(captured: string[], punctuated: string): Result {
  const ret = returnedTokens(punctuated);
  const a = captured.map(norm);
  const b = ret.map((t) => t.core.toLowerCase());

  // Fast path: same length and every word matches.
  const same = a.length === b.length && a.every((w, k) => w === b[k]);
  if (!same) {
    // Find out what changed, for the report.
    const pairs = lcsAlign(a, b);
    const changes: Change[] = [];
    let lastI = -1;
    for (let k = 0; k < pairs.length; k++) {
      const [x, y] = pairs[k];
      if (x >= 0 && y >= 0) { lastI = x; continue; }
      // a dropped word directly followed by an added one = a changed word
      const next = pairs[k + 1];
      if (x >= 0 && next && next[0] === -1 && next[1] >= 0) {
        changes.push({ kind: 'changed', i: x, captured: captured[x], returned: ret[next[1]].raw });
        lastI = x; k++; continue;
      }
      if (x === -1 && next && next[0] >= 0 && next[1] === -1) {
        changes.push({ kind: 'changed', i: next[0], captured: captured[next[0]], returned: ret[y].raw });
        lastI = next[0]; k++; continue;
      }
      if (x >= 0) { changes.push({ kind: 'dropped', i: x, captured: captured[x] }); lastI = x; }
      else changes.push({ kind: 'added', afterI: lastI, returned: ret[y].raw });
    }
    // Salvage (D-084): punctuation and case of every word the model left unchanged.
    // Words it changed keep their captured form; no word is ever replaced.
    const salvaged: Edit[] = [];
    for (const [x, y] of pairs) {
      if (x < 0 || y < 0) continue;
      const e = editFor(x, captured[x], ret[y]);
      if (e) salvaged.push(e);
    }
    return { ok: false, changes, salvaged };
  }

  // Same words: compare punctuation and case word by word.
  const edits: Edit[] = [];
  for (let k = 0; k < captured.length; k++) {
    const e = editFor(k, captured[k], ret[k]);
    if (e) edits.push(e);
  }
  return { ok: true, edits };
}

/** The edit that turns one captured word into the returned one (same word), or null. */
function editFor(k: number, captured: string, r: { before: string; core: string; after: string }): Edit | null {
  const cap = splitToken(captured);
  const e: Edit = { i: k };
  if (r.before && r.before !== cap.before) e.before = r.before;
  if (r.after !== cap.after) e.after = r.after; // may be "" = remove captured punctuation
  if (r.core !== cap.core) e.casing = r.core;
  if (/[.!?…]/.test(r.after)) e.sentenceEnd = true;
  return Object.keys(e).length > 1 ? e : null;
}

/**
 * Safety net (D-084): a run of more than `max` words without a sentence end is
 * split at the longest pause between two words (from the json3 start times),
 * at least `min` words into the run. The split is a sentence boundary only:
 * no mark is added, the text stays as captured. Returns the edits with the
 * added boundaries (an existing edit on that word gets `sentenceEnd` too).
 */
export function splitLongRuns(words: string[], startMs: number[], edits: Edit[], max = 40, min = 10): Edit[] {
  const byI = new Map(edits.map((e) => [e.i, { ...e }]));
  const isEnd = (k: number) => byI.get(k)?.sentenceEnd ?? /[.!?…]/.test(splitToken(words[k]).after);
  let runStart = 0;
  for (let k = 0; k < words.length; k++) {
    if (isEnd(k)) { runStart = k + 1; continue; }
    if (k - runStart + 1 <= max) continue;
    // the run is too long: split after the word with the longest pause behind it
    let best = -1, bestGap = -1;
    for (let j = runStart + min - 1; j < k; j++) {
      const gap = startMs[j + 1] - startMs[j];
      if (gap > bestGap) { bestGap = gap; best = j; }
    }
    const e = byI.get(best) ?? { i: best };
    e.sentenceEnd = true;
    e.pause = true;
    byI.set(best, e);
    runStart = best + 1;
  }
  return [...byI.values()].sort((a, b) => a.i - b.i);
}

/** Apply edits to the captured words (what the learner would see). */
export function applyEdits(captured: string[], edits: Edit[]): string[] {
  const byI = new Map(edits.map((e) => [e.i, e]));
  return captured.map((w, k) => {
    const e = byI.get(k);
    if (!e) return w;
    const p = splitToken(w);
    return (e.before ?? p.before) + (e.casing ?? p.core) + (e.after ?? p.after);
  });
}

/** Sentences (as text) from applied words, for the manual quality check. */
export function sentences(words: string[], edits: Edit[]): string[] {
  const ends = new Set(edits.filter((e) => e.sentenceEnd).map((e) => e.i));
  const out: string[] = [];
  let cur: string[] = [];
  words.forEach((w, k) => {
    cur.push(w);
    if (ends.has(k)) { out.push(cur.join(' ')); cur = []; }
  });
  if (cur.length) out.push(cur.join(' '));
  return out;
}
