// Tests for deriveEdits (the Block A exercise). Run: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { deriveEdits, applyEdits, splitToken } from './align.ts';
import { ruleJoins } from './extract.ts';

const cap = 'ich weiß nicht ob das geht aber wir versuchen es'.split(' ');

test('accepts punctuation and capitals only', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Aber wir versuchen es.');
  assert.equal(r.ok, true);
  if (!r.ok) return;
  assert.deepEqual(applyEdits(cap, r.edits).join(' '), 'Ich weiß nicht, ob das geht. Aber wir versuchen es.');
  assert.deepEqual(r.edits.filter((e) => e.sentenceEnd).map((e) => e.i), [5, 9]);
});

test('rejects a changed word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das klappt. Aber wir versuchen es.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'changed', i: 5, captured: 'geht', returned: 'klappt.' }]);
});

test('rejects a dropped word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Wir versuchen es.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'dropped', i: 6, captured: 'aber' }]);
});

test('rejects an added word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Aber wir versuchen es doch.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'added', afterI: 9, returned: 'doch.' }]);
});

test('glues a free-standing dash to the previous word', () => {
  const r = deriveEdits(['das', 'ist', 'gut'], 'Das ist – gut.');
  assert.equal(r.ok, true);
});

test('handles already punctuated captions', () => {
  const r = deriveEdits(['Hallo,', 'wie', 'geht’s?'], 'Hallo, wie geht’s?');
  assert.equal(r.ok, true);
  // nothing to change, but the sentence end is still recorded
  if (r.ok) assert.deepEqual(r.edits, [{ i: 2, sentenceEnd: true }]);
});

test('splitToken', () => {
  assert.deepEqual(splitToken('„Hallo,'), { before: '„', core: 'Hallo', after: ',' });
  assert.deepEqual(splitToken('geht’s?'), { before: '', core: 'geht’s', after: '?' });
});

test('ignores captured tokens that are only punctuation (speaker dashes)', () => {
  const c = ['-', 'Kommst', 'du?', '-', 'Ja,', 'gleich.'];
  const r = deriveEdits(c, '– Kommst du? – Ja, gleich.');
  assert.equal(r.ok, true);
  const r2 = deriveEdits(c, 'Kommst du? Ja, gleich.');
  assert.equal(r2.ok, true);
  if (r2.ok) assert.deepEqual(r2.edits.map((e) => e.i), [2, 5]);
  const r3 = deriveEdits(c, 'Kommst du? Nein, gleich.');
  assert.equal(r3.ok, false);
  if (!r3.ok) assert.deepEqual(r3.changes, [{ kind: 'changed', i: 4, captured: 'Ja,', returned: 'Nein,' }]);
});

test('treats >> speaker marks as punctuation', () => {
  const r = deriveEdits(['>>', 'yeah', 'right'], 'Yeah, right.');
  assert.equal(r.ok, true);
  assert.equal(deriveEdits(['>>', 'yeah'], '>> Yeah.').ok, true);
});

test('rule joins: full stop + lowercase word, but not abbreviations, ordinals, ellipses or brands', () => {
  const w = 'Wir haben Flugzeuge. wir haben z.B. viele am 17. september ich... und dann. iPhone Ja. und gucken.'.split(' ');
  assert.deepEqual(ruleJoins(w).map((k) => w[k]), ['Flugzeuge.', 'Ja.']);
});

// D-084: salvage and safety net
import { splitLongRuns, sentences } from './align.ts';

test('a rejected chunk keeps the punctuation of its unchanged words', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das klappt. Aber wir versuchen es.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  // "geht" stays as captured (and loses the model's full stop with "klappt."), everything else is punctuated
  assert.equal(applyEdits(cap, r.salvaged).join(' '), 'Ich weiß nicht, ob das geht Aber wir versuchen es.');
  assert.deepEqual(r.salvaged.filter((e) => e.sentenceEnd).map((e) => e.i), [9]);
});

test('salvage never replaces, drops or adds a word', () => {
  const r = deriveEdits(cap, 'Ich weiß, ob das klappt. Wir versuchen es doch.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  const shown = applyEdits(cap, r.salvaged);
  assert.equal(shown.length, cap.length);
  shown.forEach((w, k) => assert.equal(splitToken(w).core.toLowerCase(), cap[k]));
});

test('safety net splits a long run at the longest pause, without visible marks', () => {
  const words = Array.from({ length: 50 }, (_, k) => `w${k}`);
  const t = words.map((_, k) => k * 300 + (k > 22 ? 2000 : 0)); // 2 s pause after w22
  const edits = splitLongRuns(words, t, [], 40, 10);
  assert.deepEqual(edits.map((e) => e.i), [22]);
  assert.equal(edits[0].pause, true);
  assert.deepEqual(applyEdits(words, edits), words);
  assert.deepEqual(sentences(words, edits).map((s) => s.split(' ').length), [23, 27]);
});

test('safety net leaves runs up to the limit alone', () => {
  const words = Array.from({ length: 40 }, (_, k) => `w${k}`);
  assert.deepEqual(splitLongRuns(words, words.map((_, k) => k * 300), [], 40), []);
  const punct = [...Array(30).fill('a'), 'b.', ...Array(30).fill('c')];
  assert.deepEqual(splitLongRuns(punct, punct.map((_, k) => k * 300), [], 40), []);
});

test('safety net keeps splitting a very long wall', () => {
  const words = Array.from({ length: 500 }, (_, k) => `w${k}`);
  const edits = splitLongRuns(words, words.map((_, k) => k * 300 + (k % 17 === 0 ? 900 : 0)), [], 40);
  const lens = sentences(words, edits).map((s) => s.split(' ').length);
  assert.ok(Math.max(...lens) <= 40, `longest ${Math.max(...lens)}`);
  assert.equal(lens.reduce((a, b) => a + b, 0), 500);
});
