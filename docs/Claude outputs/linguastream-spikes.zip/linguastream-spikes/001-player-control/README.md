# Spike 001 – player control

Throwaway code for `docs/changes/001-player-control-spike/spec.md`. Builds on spike 000 (same capture hook and popup). Not part of the app repository (D-039). Record results in `docs/changes/001-player-control-spike/results.md`.

## What's new
- `extension/control.js` (MAIN world, next to `hook.js`): switches on the German caption track **only when you click a popup button** (D-071). Uploaded German first, auto second, never a translation (D-073). It switches once and never switches back if you change the track (D-073).
  - **A** – the player's own undocumented methods: `getOption('captions','tracklist')`, `setOption('captions','track', …)`.
  - **B** – clicks YouTube's buttons: CC, then Settings → Subtitles → German if needed.
  - **Restore previous** – puts back what was on before the first switch (check 4).
  - **Status** – the track loaded now, the last caption file, and the audio tracks (checks 7, 9).
- `extension/bridge.js` relays popup commands to `control.js`.
- `page/index.html` loads the embed through YouTube's IFrame Player API, with method **C** buttons: our page drives its own embed, no extension.

## Setup
1. On `opera://extensions`, remove spike 000, then **Load unpacked** → this `extension` folder. Keep other caption extensions off.
2. **Reload any YouTube tab** that was open before (content scripts only enter pages loaded after the extension).
3. Test page: in `page`, run `npx serve -l 8080`, open `http://localhost:8080`.

Press **Clear** in the popup before each run; **Copy report** after.

## Runs
| Run | Where | What to do | Checks |
|---|---|---|---|
| A1 | youtube.com, German video with auto captions only, CC off | Popup: German on: A | 1, 2 |
| A2 | same, video with uploaded + auto German | German on: A; expect the uploaded track | 1, 6 |
| A3 | same, after turning on **English** captions yourself | German on: A, then Restore previous | 1, 4 |
| A4 | click another video in YouTube (no reload) | German on: A again | 3 |
| B1–B4 | same as A1–A4 | German on: B | 1–4 |
| E | test page, plain and nocookie | Popup A and B, then page button C | 1, 2 |
| N | a video with no German captions | A, B, C | 5 |
| S | after A on youtube.com, open a different German video in a **new tab** | Does YouTube keep German on? | 4 |
| U | after A worked | Switch the track yourself: auto German, English, off. Click Status after each | 9 |
| D | a video with AI-dubbed audio | Switch the audio track in YouTube's settings, then Status | 7 |

Watch DevTools → Console on the YouTube tab for red errors from YouTube's own code after A and B (check 8).

## Reading the popup
- **Player control** table: action, result (`switched`, `no German track`, `failed`), the caption file that arrived afterwards, every step taken (track list, chosen track, the setting before), and timing since page load.
- A `switched` with "no German file within 4 s" means the call ran but the player didn't load German captions.
- Uploaded tracks: compare the caption row's "segments timed" with spike 000's auto tracks (check 6).
