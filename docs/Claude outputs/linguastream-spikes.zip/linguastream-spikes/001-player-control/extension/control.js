// control.js – runs in the MAIN world next to hook.js.
// Switches on the German caption track, but ONLY when the popup asks
// (a user click, D-071). Switches once and never fights the user (D-073).

(() => {
  // Don't run twice in the same frame.
  if (window.__lsSpike001Control) return;
  window.__lsSpike001Control = true;

  // The hook's tag: we read its caption messages and post our results.
  const TAG = 'ls-spike-000';
  // Commands from the bridge carry this tag.
  const CMD = 'ls-spike-001-cmd';

  // Same frame description as the hook uses.
  const frame = {
    host: location.host,
    path: location.pathname,
    isTop: window.top === window,
    parentOrigin: (location.ancestorOrigins && location.ancestorOrigins[0]) || null,
  };

  // Post a result for the bridge to store.
  const post = (type, payload) => {
    try {
      window.postMessage({ source: TAG, type, payload: { at: Date.now(), frame, ...payload } }, location.origin);
    } catch (_) {}
  };

  // The last caption file the hook saw in this frame (language, kind, time).
  let lastCaption = null;
  // The caption setting before our first switch, for "restore" (check 4).
  let previousTrack;
  // Wait helper.
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Listen to the hook's own messages to learn which caption file loaded.
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    // A caption file seen by the hook.
    if (ev.data.source === TAG && ev.data.type === 'timedtext') {
      const p = (ev.data.payload && ev.data.payload.params) || {};
      lastCaption = { lang: p.lang, kind: p.kind || 'manual', tlang: p.tlang || null, at: Date.now() };
    }
    // A command from the popup, relayed by the bridge.
    if (ev.data.source === CMD) run(ev.data.cmd, ev.data.method);
  });

  // Log SPA navigation on youtube.com (check 3).
  window.addEventListener('yt-navigate-finish', () => {
    post('control', { action: 'navigate', result: 'info', detail: location.pathname + location.search });
  });

  // Find YouTube's player element in this frame.
  function getPlayer() {
    return document.getElementById('movie_player') || document.querySelector('.html5-video-player');
  }

  // Call an undocumented player method safely; returns { ok, value } or { ok:false, error }.
  function call(p, name, ...args) {
    if (!p || typeof p[name] !== 'function') return { ok: false, error: name + ' missing' };
    try { return { ok: true, value: p[name](...args) }; }
    catch (e) { return { ok: false, error: name + ': ' + ((e && e.message) || e) }; }
  }

  // Short text for a track object, for the log.
  const describe = (t) => {
    if (!t || typeof t !== 'object' || !Object.keys(t).length) return 'none';
    return [t.languageCode, t.kind || 'manual', t.vss_id || t.vssId || '', t.displayName || t.languageName || '']
      .filter(Boolean).join(' ');
  };

  // Pick the German track: uploaded first, auto second (D-073). Never a translation.
  function pickGerman(list) {
    const de = (list || []).filter((t) => t && /^de(\b|-|_)/i.test(t.languageCode || '') && !t.translationLanguage);
    return de.find((t) => t.kind !== 'asr') || de.find((t) => t.kind === 'asr') || null;
  }

  // Wait up to `ms` for a German caption file to arrive after `since`.
  async function waitForGerman(since, ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (lastCaption && lastCaption.at >= since && /^de/i.test(lastCaption.lang || '') && !lastCaption.tlang) return lastCaption;
      await sleep(200);
    }
    return null;
  }

  // Method A: the player's own (undocumented) caption methods.
  async function methodA(p) {
    const steps = [];
    // Remember the user's setting the first time (check 4).
    const before = call(p, 'getOption', 'captions', 'track');
    if (previousTrack === undefined) previousTrack = before.ok ? before.value : null;
    steps.push('before: ' + (before.ok ? describe(before.value) : before.error));
    // Make sure the captions module is loaded.
    const lm = call(p, 'loadModule', 'captions');
    steps.push('loadModule: ' + (lm.ok ? 'ok' : lm.error));
    // The module may need a moment.
    await sleep(300);
    // Track list; some versions only include auto tracks with includeAsr.
    let list = call(p, 'getOption', 'captions', 'tracklist', { includeAsr: true });
    if (!list.ok || !Array.isArray(list.value) || !list.value.length) list = call(p, 'getOption', 'captions', 'tracklist');
    const tracks = list.ok && Array.isArray(list.value) ? list.value : [];
    steps.push('tracklist: ' + (tracks.length ? tracks.map(describe).join(' | ') : (list.error || 'empty')));
    // Choose the German track.
    const chosen = pickGerman(tracks);
    if (!chosen) return { result: 'no German track', steps };
    steps.push('chosen: ' + describe(chosen));
    // Switch.
    const set = call(p, 'setOption', 'captions', 'track', chosen);
    steps.push('setOption: ' + (set.ok ? 'ok' : set.error));
    return { result: set.ok ? 'switched' : 'failed', steps };
  }

  // Method B: click YouTube's own buttons like a user would.
  async function methodB(p) {
    const steps = [];
    const root = p || document;
    // The CC button.
    const cc = root.querySelector('.ytp-subtitles-button');
    if (!cc) return { result: 'failed', steps: ['no CC button'] };
    const pressed = cc.getAttribute('aria-pressed') === 'true';
    steps.push('CC was ' + (pressed ? 'on' : 'off'));
    if (previousTrack === undefined) previousTrack = pressed ? 'cc-on' : 'cc-off';
    if (!pressed) { cc.click(); steps.push('clicked CC'); }
    // If German arrives, we're done.
    const since = Date.now() - (pressed ? 0 : 50);
    if (await waitForGerman(since, 2500)) return { result: 'switched', steps };
    // Otherwise go through Settings → Subtitles → German (labels differ by UI language).
    const settings = root.querySelector('.ytp-settings-button');
    if (!settings) return { result: 'CC on, wrong language; no settings button', steps };
    settings.click();
    await sleep(400);
    const items = [...root.querySelectorAll('.ytp-panel-menu .ytp-menuitem')];
    const subs = items.find((el) => /untertitel|subtitles|captions|cc/i.test(el.textContent || ''));
    if (!subs) { settings.click(); return { result: 'no Subtitles item in settings', steps }; }
    subs.click();
    steps.push('opened: ' + subs.textContent.trim().slice(0, 40));
    await sleep(400);
    const options = [...root.querySelectorAll('.ytp-panel-menu .ytp-menuitem')];
    steps.push('options: ' + options.map((el) => el.textContent.trim()).join(' | ').slice(0, 300));
    // Uploaded German first: a German label without "auto" in it.
    const isGerman = (el) => /deutsch|german/i.test(el.textContent || '');
    const isAuto = (el) => /automatisch|auto-generated|auto/i.test(el.textContent || '');
    const pick = options.find((el) => isGerman(el) && !isAuto(el)) || options.find(isGerman);
    if (!pick) { settings.click(); return { result: 'no German option in menu', steps }; }
    pick.click();
    steps.push('picked: ' + pick.textContent.trim());
    return { result: 'switched', steps };
  }

  // Restore what the user had before our first switch (check 4).
  async function restore(p) {
    if (previousTrack === undefined) return { result: 'nothing to restore', steps: [] };
    if (previousTrack === 'cc-off' || previousTrack === 'cc-on') {
      const cc = (p || document).querySelector('.ytp-subtitles-button');
      const on = cc && cc.getAttribute('aria-pressed') === 'true';
      if (cc && on !== (previousTrack === 'cc-on')) cc.click();
      return { result: 'restored CC ' + previousTrack.slice(3), steps: [] };
    }
    const set = call(p, 'setOption', 'captions', 'track', previousTrack || {});
    return { result: set.ok ? 'restored' : 'failed', steps: ['to: ' + describe(previousTrack) + (set.ok ? '' : ' (' + set.error + ')')] };
  }

  // Report what is loaded now (check 9) plus audio tracks (check 7).
  function status(p) {
    const track = call(p, 'getOption', 'captions', 'track');
    const audio = call(p, 'getAudioTrack');
    const audios = call(p, 'getAvailableAudioTracks');
    const name = (a) => a && (a.getLanguageInfo ? JSON.stringify(a.getLanguageInfo()) : (a.id || JSON.stringify(a).slice(0, 80)));
    return {
      result: 'info',
      steps: [
        'track now: ' + (track.ok ? describe(track.value) : track.error),
        'last caption file: ' + (lastCaption ? lastCaption.lang + ' (' + lastCaption.kind + ')' + (lastCaption.tlang ? ' tlang ' + lastCaption.tlang : '') : 'none'),
        'audio now: ' + (audio.ok ? name(audio.value) : audio.error),
        'audio tracks: ' + (audios.ok && Array.isArray(audios.value) ? audios.value.map(name).join(' | ') : audios.error || 'none'),
      ],
    };
  }

  // Run one command and log the result.
  async function run(cmd, method) {
    const p = getPlayer();
    // Frames without a player (e.g. small YouTube iframes) stay quiet.
    if (!p) return;
    const t0 = performance.now();
    const started = Date.now();
    let out;
    try {
      if (cmd === 'enable') out = method === 'B' ? await methodB(p) : await methodA(p);
      else if (cmd === 'restore') out = await restore(p);
      else out = status(p);
    } catch (e) {
      out = { result: 'error', steps: [String((e && e.message) || e)] };
    }
    // For switches: did a German caption file actually arrive (check 1)?
    if (cmd === 'enable' && out.result === 'switched') {
      const got = await waitForGerman(started, 4000);
      out.captured = got ? got.lang + ' (' + got.kind + ')' : 'no German file within 4 s';
    }
    post('control', {
      action: cmd === 'enable' ? 'enable ' + method : cmd,
      result: out.result,
      captured: out.captured || null,
      steps: out.steps,
      // Check 2: how long after page load, and how long it took.
      msSincePageLoad: Math.round(t0),
      tookMs: Math.round(performance.now() - t0),
      url: location.pathname + location.search,
    });
  }
})();
