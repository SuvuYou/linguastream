// bridge.js – ISOLATED world. Saves the hook's messages, and relays popup
// commands to control.js (which runs in the MAIN world).
const TAG = 'ls-spike-000';
const CMD = 'ls-spike-001-cmd';

// Hook/control → storage.
window.addEventListener('message', (ev) => {
  if (ev.source !== window || !ev.data || ev.data.source !== TAG) return;
  const { type, payload } = ev.data;
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const entry = { id, type, ...payload };
  const items = {};
  if (typeof entry.raw === 'string') {
    items['raw:' + id] = entry.raw;
    entry.hasRaw = true;
  }
  delete entry.raw;
  items['e:' + id] = entry;
  chrome.storage.local.set(items);
});

// Popup → control.js. Every frame of the tab gets the message; frames
// without a player ignore it.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.source !== CMD) return;
  window.postMessage({ source: CMD, cmd: msg.cmd, method: msg.method }, location.origin);
  sendResponse({ ok: true });
});
