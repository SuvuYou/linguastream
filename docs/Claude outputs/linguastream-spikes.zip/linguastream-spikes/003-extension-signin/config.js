// config.js – shared by the page, the extension and the server. Fill in the
// firebaseConfig of your TEST project (Firebase console → Project settings →
// Your apps → Web app). These values are not secret; the service-account key is.

export const firebaseConfig = {
  apiKey: 'PASTE',
  authDomain: 'PASTE.firebaseapp.com',
  projectId: 'PASTE',
  appId: 'PASTE',
};

// Fixed by the "key" in extension/manifest.json, so it is the same on every
// computer and in every browser. Don't change one without the other.
export const EXTENSION_ID = 'kboemeffohobecdiilicpinijpchenbf';

// The spike server (page + API on the same origin).
export const API = 'http://localhost:8080';
