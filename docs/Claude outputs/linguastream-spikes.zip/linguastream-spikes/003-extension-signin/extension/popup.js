// popup.js – no Firebase here: it asks the service worker, which owns the session.
const $ = (id) => document.getElementById(id);
const ask = (msg) => chrome.runtime.sendMessage(msg);
const t = (s) => new Date(s * 1000).toLocaleTimeString();

async function refresh() {
  const { user } = await ask({ type: 'whoami' });
  $('who').textContent = user ? `${user.email ?? ''} (${user.uid})` : 'nobody';
  const { log = [] } = await chrome.storage.local.get('log');
  $('log').innerHTML = log.map((l) =>
    `<tr><td class="muted">${new Date(l.at).toLocaleTimeString()}</td><td>${l.event}</td><td class="muted">${l.detail.replace(/</g, '&lt;')}</td></tr>`).join('');
}

async function call(force) {
  $('result').textContent = 'Calling…';
  const r = await ask({ type: 'callMe', force });
  $('result').textContent = `HTTP ${r.status}\n${r.body}` +
    (r.tokenIssuedAt ? `\nToken issued ${t(r.tokenIssuedAt)}, expires ${t(r.tokenExpires)}` : '');
  refresh();
}

$('call').onclick = () => call(false);
$('force').onclick = () => call(true);
$('clear').onclick = async () => { await chrome.storage.local.set({ log: [] }); refresh(); };
refresh();
