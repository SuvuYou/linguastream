// background.js – the extension's service worker (bundled into dist/ by esbuild,
// because MV3 extensions can't load code from the internet).
// It is the only part of the extension that talks to Firebase and the API.

import { initializeApp } from 'firebase/app';
// The extension build of Firebase Auth (Web SDK 10.8+). The normal
// 'firebase/auth' pulls in code that MV3 doesn't allow.
import { getAuth, signInWithCustomToken, signOut, onAuthStateChanged } from 'firebase/auth/web-extension';
import { firebaseConfig, API } from '../../config.js';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// The only page allowed to hand us a token (also limited in the manifest).
const ALLOWED_ORIGIN = new URL(API).origin;

// A small log in storage, so the popup can show what happened even after
// Chrome stopped and restarted this service worker (checks 5–8).
async function log(event, detail = '') {
  const { log = [] } = await chrome.storage.local.get('log');
  log.unshift({ at: Date.now(), event, detail: String(detail).slice(0, 300) });
  await chrome.storage.local.set({ log: log.slice(0, 50) });
}
log('service worker started');

// Fires on start (with the restored user, if any) and on every change.
onAuthStateChanged(auth, (user) => log('auth state', user ? user.uid + ' ' + (user.email ?? '') : 'signed out'));

// Messages from our web page (externally_connectable).
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  // Check 2: refuse anything not from our page, even if the manifest let it through.
  if (sender.origin !== ALLOWED_ORIGIN) {
    log('refused message', 'from ' + sender.origin);
    sendResponse({ ok: false, error: 'origin not allowed' });
    return;
  }
  (async () => {
    try {
      if (msg?.type === 'connect' && typeof msg.customToken === 'string') {
        // Check 3: sign in with the one-time token from our server.
        const cred = await signInWithCustomToken(auth, msg.customToken);
        await log('signed in with custom token', cred.user.uid);
        sendResponse({ ok: true, uid: cred.user.uid });
      } else if (msg?.type === 'disconnect') {
        await signOut(auth);
        await log('signed out by page');
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: 'unknown message' });
      }
    } catch (e) {
      await log('error', e.code || e.message);
      sendResponse({ ok: false, error: e.code || e.message });
    }
  })();
  return true; // we answer asynchronously
});

// Messages from our own popup.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    // Wait until Firebase has restored any saved session (check 5).
    await auth.authStateReady();
    const user = auth.currentUser;
    if (msg?.type === 'whoami') {
      sendResponse({ user: user && { uid: user.uid, email: user.email } });
      return;
    }
    if (msg?.type === 'callMe') {
      if (!user) { sendResponse({ status: 0, body: 'not signed in' }); return; }
      try {
        // Check 6: getIdToken refreshes the token itself when it is near expiry;
        // force=true asks for a new one now.
        const token = await user.getIdToken(!!msg.force);
        const claims = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
        // Check 4: call the API with our own ID token.
        const res = await fetch(API + '/api/me', { headers: { Authorization: 'Bearer ' + token } });
        const body = await res.text();
        await log('GET /api/me → ' + res.status, body);
        // Check 7: a revoked session → sign out locally, so the popup shows it.
        if (res.status === 401 && /revoked|disabled|user-not-found/.test(body)) {
          await signOut(auth);
          await log('signed out: session revoked on the server');
        }
        sendResponse({ status: res.status, body, tokenIssuedAt: claims.iat, tokenExpires: claims.exp });
      } catch (e) {
        // A refresh fails after revocation or account deletion (checks 7–8).
        await log('error calling API', e.code || e.message);
        if (/user-token-expired|user-disabled|user-not-found|invalid-user-token/.test(e.code || '')) await signOut(auth);
        sendResponse({ status: 0, body: e.code || e.message });
      }
      return;
    }
    sendResponse({ error: 'unknown message' });
  })();
  return true;
});
