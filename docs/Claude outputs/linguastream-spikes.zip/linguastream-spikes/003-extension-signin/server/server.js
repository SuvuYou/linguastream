// server.js – stands in for NestJS (D-053). Serves the test page and three API
// routes. Listens on 8080 (allowed origin) and 8081 (not allowed, check 2).
// Run: npm start   (needs SERVICE_ACCOUNT in .env)

import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

// the spike folder (fileURLToPath also handles Windows drive letters and spaces)
const root = fileURLToPath(new URL('..', import.meta.url));
const keyPath = process.env.SERVICE_ACCOUNT;
if (!keyPath) {
  console.error('SERVICE_ACCOUNT missing: put the path of your service-account JSON in .env');
  process.exit(1);
}
initializeApp({ credential: cert(JSON.parse(await readFile(keyPath, 'utf8'))) });
const auth = getAuth();

const types = { '.html': 'text/html', '.js': 'text/javascript', '.map': 'application/json' };

// Verify "Authorization: Bearer <ID token>", with revocation checked (checks 4, 7, 8).
async function user(req) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? '');
  if (!m) throw Object.assign(new Error('no token'), { code: 'no-token' });
  return auth.verifyIdToken(m[1], true);
}

async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const send = (status, body, type = 'application/json') => {
    res.writeHead(status, { 'Content-Type': type });
    res.end(typeof body === 'string' ? body : JSON.stringify(body));
  };
  try {
    if (url.pathname === '/api/extension-token' && req.method === 'POST') {
      const u = await user(req);
      const customToken = await auth.createCustomToken(u.uid);
      console.log('custom token for', u.uid);
      return send(200, { customToken });
    }
    if (url.pathname === '/api/me' && req.method === 'GET') {
      const u = await user(req);
      console.log('/api/me ok for', u.uid);
      return send(200, { uid: u.uid, email: u.email, signedInAt: new Date(u.auth_time * 1000).toISOString() });
    }
    if (url.pathname === '/api/logout' && req.method === 'POST') {
      const u = await user(req);
      await auth.revokeRefreshTokens(u.uid);
      console.log('revoked sessions of', u.uid);
      return send(204, '');
    }
    // Static files: the page and its bundle; config.js is shared from the root.
    const file = url.pathname === '/' ? 'page/index.html'
      : url.pathname.startsWith('/dist/') ? join('page', url.pathname) : null;
    if (!file) return send(404, { error: 'not found' });
    const full = normalize(join(root, file));
    return send(200, await readFile(full, 'utf8'), types[extname(full)] ?? 'text/plain');
  } catch (e) {
    console.log(req.method, url.pathname, '→ 401', e.code || e.message);
    return send(e.code === 'ENOENT' ? 404 : 401, { error: e.code || e.message });
  }
}

for (const port of [8080, 8081]) createServer(handle).listen(port, () => console.log('http://localhost:' + port));
