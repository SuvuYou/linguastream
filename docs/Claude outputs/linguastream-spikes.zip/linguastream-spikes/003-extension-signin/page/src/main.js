// main.js – the test page (bundled by esbuild into page/dist/main.js).
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { firebaseConfig, EXTENSION_ID } from '../../config.js';

const auth = getAuth(initializeApp(firebaseConfig));
const $ = (id) => document.getElementById(id);
const log = (...a) => { $('log').textContent = new Date().toLocaleTimeString() + '  ' + a.join(' ') + '\n' + $('log').textContent; };

// Check 2: chrome.runtime.sendMessage only exists on pages an extension lists
// in externally_connectable. On http://localhost:8081 it should be missing.
const canMessage = !!(globalThis.chrome && chrome.runtime && chrome.runtime.sendMessage);
$('origin').innerHTML = `This page: <b>${location.origin}</b>. ` + (canMessage
  ? 'The extension accepts messages from it.'
  : '<span class="warn">No extension accepts messages from this origin (expected on port 8081, or the extension isn\'t loaded).</span>');

onAuthStateChanged(auth, (u) => { $('who').textContent = u ? `Signed in: ${u.email} (${u.uid})` : 'Not signed in'; });

// Call our API with the page's own ID token (the real app uses the session cookie).
async function api(method, path) {
  const u = auth.currentUser;
  if (!u) throw new Error('sign in on the page first');
  const res = await fetch(path, { method, headers: { Authorization: 'Bearer ' + (await u.getIdToken()) } });
  const body = await res.text();
  if (!res.ok) throw new Error(`${method} ${path} → ${res.status} ${body}`);
  return body ? JSON.parse(body) : {};
}

function toExtension(msg) {
  return new Promise((resolve) => {
    if (!canMessage) return resolve({ ok: false, error: 'chrome.runtime not available on this origin' });
    chrome.runtime.sendMessage(EXTENSION_ID, msg, (res) =>
      resolve(res ?? { ok: false, error: chrome.runtime.lastError?.message ?? 'no answer' }));
  });
}

$('signin').onclick = async () => {
  try {
    await signInWithEmailAndPassword(auth, $('email').value, $('password').value);
    log('page signed in');
  } catch (e) { log('sign-in failed:', e.code || e.message); }
};

$('connect').onclick = async () => {
  try {
    // The server mints a one-time custom token for the signed-in user (D-053)...
    const { customToken } = await api('POST', '/api/extension-token');
    log('got custom token from the server');
    // ...and the page hands it to the extension.
    const r = await toExtension({ type: 'connect', customToken });
    log('extension answered:', JSON.stringify(r));
  } catch (e) { log(String(e.message || e)); }
};

$('disconnect').onclick = async () => log('extension answered:', JSON.stringify(await toExtension({ type: 'disconnect' })));

$('logout').onclick = async () => {
  try {
    await api('POST', '/api/logout');       // revokeRefreshTokens on the server
    log('server revoked all sessions of this user');
  } catch (e) { log(String(e.message || e)); }
  await signOut(auth);
  log('page signed out');
};
