# Spike 003 – extension sign-in (D-053)

Throwaway code for `docs/changes/003-extension-signin-spike/spec.md`. Outside the app repository. Record results in `docs/changes/003-extension-signin-spike/results.md`.

## The flow being tested
1. You sign in on **our page** (email + password, Firebase web SDK).
2. **Connect extension:** the page asks our **server** for a one-time *custom token* (`POST /api/extension-token`, `createCustomToken`).
3. The page hands it to the **extension** with `chrome.runtime.sendMessage(EXTENSION_ID, …)`. Only `http://localhost:8080` may do that (`externally_connectable`, plus an origin check in the service worker).
4. The extension's **service worker** signs in with `signInWithCustomToken` from `firebase/auth/web-extension`. From now on it has its own Firebase session.
5. The popup's **Call /api/me** sends the extension's own ID token; the server verifies it with revocation checked.
6. **Log out** on the page revokes all sessions (`revokeRefreshTokens`); the extension's next call is refused and it signs itself out.

| Folder | What |
|---|---|
| `config.js` | Your test project's web config, the extension ID, the server address. Shared by all three parts |
| `server/server.js` | Plain Node standing in for NestJS: serves the page and `/api/extension-token`, `/api/me`, `/api/logout`. Listens on 8080 (allowed) and 8081 (not allowed) |
| `page/src/main.js` | The test page's script |
| `extension/` | The MV3 extension: `src/background.js` (service worker, all Firebase code), `popup.html/js` (asks the service worker, no Firebase) |

The extension's ID is fixed by the `key` in its manifest: **kboemeffohobecdiilicpinijpchenbf**, the same on every computer and browser. That answers "how does our page know the extension ID": it's a constant.

## Setup
1. **Firebase test project** (free plan, not your friends' project): console → add project → Authentication → Sign-in method → enable **Email/Password** → Users → add a test user.
2. Project settings → Your apps → add a **Web app** → copy its config into `config.js` (`apiKey`, `authDomain`, `projectId`, `appId`).
3. Project settings → Service accounts → **Generate new private key** → save it as `service-account.json` in this folder (it's in `.gitignore`; never share it).
4. In this folder (PowerShell):
   ```powershell
   copy .env.example .env
   npm install
   npm run build      # bundles Firebase into extension/dist and page/dist (check 1: note the sizes)
   npm start          # server on http://localhost:8080 and :8081
   ```
5. Browser → extensions page → **Load unpacked** → the `extension` folder. Check its ID matches the one above.
6. Open `http://localhost:8080`.

After changing `config.js` or any `src/` file, run `npm run build` again and reload the extension.

## Runs
| Check | What to do | Expect |
|---|---|---|
| 1 Bundle | `npm run build`; load the extension; open its service worker's console (extensions page → "service worker") | No errors; bundle ~220 KB |
| 2 Handoff | Open `http://localhost:8081` | The page says no extension accepts messages from it |
| 3 Sign-in | On :8080 sign in, then **Connect extension** | Page log: `extension answered: {"ok":true,"uid":…}`; popup shows the same user |
| 4 API | Popup → **Call /api/me** | HTTP 200 with your uid and email |
| 5 Restarts | Stop the service worker (extensions page, or `chrome://serviceworker-internals` / `opera://serviceworker-internals`), open the popup; then restart the browser | Still signed in; popup log shows "service worker started" and the restored user |
| 6 Refresh | After more than an hour, **Call /api/me** again; or press **Call with a fresh token** | 200; the token's issue time is new |
| 7 Revocation | Page → **Log out**, then popup → **Call /api/me** | 401 `auth/id-token-revoked`, popup shows "nobody". Note how long it took |
| 8 Deleted account | Connect again, delete the test user in the Firebase console, call again (also with a fresh token) | 401 / refresh error; the extension signs out |
| 9 Opera | Everything above in Opera and in Chrome | Same |

The server prints every request and why it refused one; the popup's log keeps the extension's side across restarts.
