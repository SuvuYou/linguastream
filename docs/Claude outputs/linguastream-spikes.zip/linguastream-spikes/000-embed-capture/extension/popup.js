// popup.js – runs in the popup window, a page of the extension itself.
// It reads what the bridge saved and draws tables.

// Shortcut: get an element by its id.
const $ = (id) => document.getElementById(id);

// Make text safe to put into HTML (stops < > & " being read as code).
const esc = (s) => String(s ?? '')
  // replace each special character with its HTML entity
  .replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Show true as a green "yes", false as a red "no", anything else as "–".
const yes = (b) =>
  b === true ? '<span class="ok">yes</span>'
  : b === false ? '<span class="no">no</span>'
  : '<span class="muted">–</span>';

// Describe a frame: "iframe www.youtube.com/embed/x in http://localhost".
const frameLabel = (f) => {
  // no frame info: empty text
  if (!f) return '';
  // top page or iframe, plus host and path
  const where = (f.isTop ? 'top ' : 'iframe ') + esc(f.host) + esc(f.path);
  // add the outer page for iframes
  return f.parentOrigin ? where + ' in ' + esc(f.parentOrigin) : where;
};

// A time like "00:49:09".
const time = (t) => new Date(t).toLocaleTimeString();

// Read all saved entries, newest first.
async function entries() {
  // null = give me everything in storage
  const all = await chrome.storage.local.get(null);
  // keep keys starting with "e:" (skip the raw files)
  return Object.keys(all).filter((k) => k.startsWith('e:'))
    // turn keys into entries
    .map((k) => all[k])
    // newest first
    .sort((a, b) => b.at - a.at);
}

// Build an HTML table from header names and finished row strings.
function table(head, rows) {
  // one <th> per header
  const th = head.map((h) => '<th>' + h + '</th>').join('');
  // header row, then the rows
  return '<table><tr>' + th + '</tr>' + rows.join('') + '</table>';
}

// One table row for a caption response.
function captionRow(c) {
  // the kept address parameters
  const p = c.params || {};
  // "asr" for auto captions, otherwise manual
  const kind = p.kind ? '(' + esc(p.kind) + ')' : '(manual)';
  // file name for the Raw download, e.g. "abc-de-asr"
  const name = esc((p.v || 'video') + '-' + (p.lang || 'xx') + '-'
    + (p.kind || 'manual'));
  // a Raw button only when a raw file was saved
  const raw = c.hasRaw
    ? '<button data-raw="' + esc(c.id) + '" data-name="' + name + '">Raw</button>'
    : '';
  // timing share, capped at 100
  const timed = c.wordTimingShare != null
    ? Math.min(100, c.wordTimingShare) + '% of segments timed' : '–';
  // the sample lines, or the start of a non-json3 file
  const sample = (c.sample || []).map(esc).join('<br>') || esc(c.head);
  // the cells, left to right
  return '<tr>'
    // when
    + '<td>' + time(c.at) + '</td>'
    // which frame, how it was read, HTTP status, player client
    + '<td>' + frameLabel(c.frame) + '<br><span class="muted">'
    + esc(c.via) + ' · HTTP ' + esc(c.status) + ' · client ' + esc(p.c)
    + '</span></td>'
    // video, language, auto or manual, translation language, pot token
    + '<td>' + esc(p.v) + '<br>lang ' + esc(p.lang) + ' ' + kind
    + (p.tlang ? '<br>tlang ' + esc(p.tlang) : '')
    + '<br><span class="muted">pot: ' + (p.hasPot ? 'yes' : 'no')
    + '</span></td>'
    // requested format, actual format, size, length
    + '<td>' + esc(p.fmt || '?') + ' → ' + esc(c.format)
    + '<br><span class="muted">' + Math.round((c.bytes || 0) / 1024)
    + ' KB, ' + esc(c.durationMin) + ' min</span></td>'
    // lines and words
    + '<td>' + esc(c.cues) + ' / ' + esc(c.words) + '</td>'
    // word timing
    + '<td>' + timed + '<br><span class="muted">' + esc(c.segs)
    + ' segments for ' + esc(c.words) + ' words</span></td>'
    // punctuation guess and counts
    + '<td>' + yes(c.looksPunctuated) + '<br><span class="muted">'
    + esc(c.sentenceEnds) + ' ends, ' + esc(c.commas) + ' commas'
    + (c.wordsPerSentenceEnd ? ', 1 per ' + c.wordsPerSentenceEnd + ' words' : '')
    + '</span></td>'
    // bracket tags
    + '<td>' + esc((c.tags || []).join(' ')) + '</td>'
    // sample lines
    + '<td class="sample">' + sample + '</td>'
    // download button
    + '<td>' + raw + '</td>'
    + '</tr>';
}

// One table row for a player response.
function playerRow(p) {
  // caption tracks, one per line: "a.de German (auto-generated)"
  const tracks = (p.captionTracks || [])
    .map((t) => esc(t.vssId) + ' ' + esc(t.name)).join('<br>') || '–';
  // audio tracks with their decoded xtags
  const audio = (p.audioTracks || []).map((a) =>
    // name, or id, or "default"
    esc(a.displayName || a.id || 'default')
    // mark the default track
    + (a.isDefault ? ' (default)' : '')
    // the decoded xtags underneath
    + '<br><span class="muted">' + esc(a.xtags) + '</span>').join('<br>')
    // none found: say whether stream data was missing
    || (p.hasStreamingData ? '–' : '<span class="muted">no streaming data</span>');
  // the cells
  return '<tr>'
    + '<td>' + time(p.at) + '</td>'
    + '<td>' + frameLabel(p.frame) + '<br><span class="muted">'
    + esc(p.where) + '</span></td>'
    + '<td>' + esc(p.videoId) + '<br><span class="muted">' + esc(p.title)
    + '</span></td>'
    // category, or a red "not found"
    + '<td>' + (esc(p.category) || '<span class="no">not found</span>') + '</td>'
    // playability, embed flag, error reason
    + '<td>' + esc(p.playability) + '<br>in embed: ' + yes(p.playableInEmbed)
    + (p.reason ? '<br>' + esc(p.reason) : '') + '</td>'
    + '<td>' + tracks + '</td>'
    + '<td>' + audio + '</td>'
    + '</tr>';
}

// Draw everything.
async function render() {
  // all entries, newest first
  const list = await entries();
  // split them by type
  const caps = list.filter((e) => e.type === 'timedtext');
  const players = list.filter((e) => e.type === 'player');
  const frames = list.filter((e) => e.type === 'frame');
  const errors = list.filter((e) => e.type === 'error');
  // caption table (only if there is something to show)
  if (caps.length) {
    $('captions').innerHTML = table(['Time', 'Frame / via', 'Track',
      'Format', 'Cues / words', 'Word offsets', 'Punctuation', 'Tags',
      'Sample', ''], caps.map(captionRow));
  }
  // player table
  if (players.length) {
    $('players').innerHTML = table(['Time', 'Frame / source', 'Video',
      'Category', 'Playable', 'Caption tracks', 'Audio tracks'],
    players.map(playerRow));
  }
  // frames: the newest 30
  if (frames.length) {
    $('frames').innerHTML = table(['Time', 'Frame'], frames.slice(0, 30)
      .map((f) => '<tr><td>' + time(f.at) + '</td><td>'
        + frameLabel(f.frame) + '</td></tr>'));
  }
  // errors
  if (errors.length) {
    $('errors').innerHTML = table(['Time', 'Frame', 'Error'], errors
      .map((e) => '<tr><td>' + time(e.at) + '</td><td>'
        + frameLabel(e.frame) + '</td><td><pre>' + esc(e.where || '')
        + ' ' + esc(e.message) + '</pre></td></tr>'));
  }
  // counts at the top
  $('status').textContent = caps.length + ' caption, ' + players.length
    + ' player, ' + frames.length + ' frame entries';
}

// The report: all entries (without raw files) as pretty JSON.
async function report() {
  // read the entries
  const list = await entries();
  // add the spike name, browser and time
  return JSON.stringify({ spike: '000-embed-capture',
    userAgent: navigator.userAgent, createdAt: new Date().toISOString(),
    entries: list }, null, 2);
}

// Save text as a file.
function download(name, text) {
  // a hidden link
  const a = document.createElement('a');
  // a temporary address for the text, held in memory
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  // the file name to save as
  a.download = name;
  // "click" it to start the download
  a.click();
  // free the memory a few seconds later
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

// Copy report: needs a click, which is why it's a button.
$('copy').onclick = async () => {
  // write the report to the clipboard
  await navigator.clipboard.writeText(await report());
  // confirm
  $('status').textContent = 'Report copied.';
};

// Download report as a file.
$('dl').onclick = async () => download('spike-000-report.json', await report());

// Clear: delete everything and redraw.
$('clear').onclick = async () => {
  // empty the extension's storage
  await chrome.storage.local.clear();
  // reload the popup
  location.reload();
};

// One listener for all Raw buttons (they are created later).
document.addEventListener('click', async (ev) => {
  // the entry id stored on the button, if a Raw button was clicked
  const id = ev.target && ev.target.dataset && ev.target.dataset.raw;
  // some other click: ignore
  if (!id) return;
  // the raw file's key
  const key = 'raw:' + id;
  // read it from storage
  const got = await chrome.storage.local.get(key);
  // save it as "<video>-<lang>-<kind>.json3.json"
  download(ev.target.dataset.name + '.json3.json', got[key] || '');
});

// Redraw whenever the bridge saves something new.
chrome.storage.onChanged.addListener(render);

// Draw once when the popup opens.
render();
