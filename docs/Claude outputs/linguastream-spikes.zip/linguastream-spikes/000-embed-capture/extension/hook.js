// hook.js – runs inside YouTube's own page (the MAIN world).
// It only READS responses the player asked for. It never sends anything.

// An arrow function that calls itself at once, so our variables
// stay private and don't clash with YouTube's.
(() => {
  // If this script was injected twice into the same frame, stop here.
  if (window.__lsSpike000) return;
  // Leave a marker so a second copy knows we already ran.
  window.__lsSpike000 = true;

  // A tag on every message, so the bridge can tell ours from others.
  const TAG = 'ls-spike-000';

  // Describe the frame we run in; every message carries this.
  const frame = {
    // e.g. "www.youtube.com"
    host: location.host,
    // e.g. "/watch" or "/embed/abc123"
    path: location.pathname,
    // true on the main page, false inside an iframe (the embed)
    isTop: window.top === window,
    // the page around the iframe, e.g. "http://localhost:8080"
    parentOrigin:
      // ancestorOrigins lists the origins of the frames above us
      (location.ancestorOrigins && location.ancestorOrigins[0]) ||
      // null when there is no parent (we are the top page)
      null,
  };

  // Send one message to the bridge in the same window.
  const post = (type, payload) => {
    // try: posting must never break YouTube's page
    try {
      // postMessage hands data to any listener on this window
      window.postMessage(
        // the message: our tag, a type, and the data with time + frame
        { source: TAG, type, payload: { at: Date.now(), frame, ...payload } },
        // only deliver to listeners of this same origin
        location.origin,
      );
      // swallow any error on purpose
    } catch (_) {}
  };

  // First message: "the hook is running in this frame" (check 1).
  post('frame', {});

  // True for caption requests.
  const isTimedText = (u) => u.includes('/api/timedtext');
  // True for player-data requests.
  const isPlayer = (u) => u.includes('/youtubei/v1/player');

  // Parse JSON without throwing; returns null if it isn't JSON.
  const safeJson = (t) => {
    // try to parse
    try {
      // strings get parsed; objects are returned as they are
      return typeof t === 'string' ? JSON.parse(t) : t;
      // not JSON: give back null
    } catch (_) { return null; }
  };

  // Address parameters worth keeping. The pot token is NOT in this list.
  const KEEP = ['v', 'lang', 'kind', 'fmt', 'tlang', 'name', 'c',
    'cver', 'caps', 'potc', 'xorb', 'xobt', 'xovt'];

  // Pick the harmless parameters out of a caption address.
  function params(url) {
    // URL splits an address into parts
    const u = new URL(url);
    // start the result with the host name
    const o = { host: u.host };
    // copy each kept parameter that is present
    for (const k of KEEP) {
      // has() checks, get() reads the value
      if (u.searchParams.has(k)) o[k] = u.searchParams.get(k);
    }
    // record only WHETHER a pot token was there, never its value
    o.hasPot = u.searchParams.has('pot');
    // hand back the small object
    return o;
  }

  // Turn one caption response into a summary (plus the raw text).
  function summariseTimedText(url, status, text, via) {
    // basics: how we got it, HTTP status, size, address parameters
    const s = { via, status, bytes: text ? text.length : 0,
      params: params(url) };
    // try to read the body as JSON
    const j = safeJson(text);
    // not json3 (e.g. an XML format): keep the start and stop here
    if (!j || !Array.isArray(j.events)) {
      // mark the format as unknown
      s.format = 'not-json3';
      // keep the first 300 characters to look at
      s.head = text ? text.slice(0, 300) : null;
      // keep the full text for download
      s.raw = text;
      // done
      return s;
    }
    // lines with real words (skip the "\n" line-break events)
    const cues = j.events.filter((e) =>
      // has a segs list and at least one non-blank piece
      Array.isArray(e.segs) && e.segs.some((g) => (g.utf8 || '').trim()));
    // all text pieces of all lines in one list
    const segs = cues.flatMap((e) => e.segs);
    // each line's text: join its pieces, squash spaces
    const cueText = cues.map((e) =>
      e.segs.map((g) => g.utf8 || '').join('')
        .replace(/\s+/g, ' ').trim());
    // the whole transcript as one string
    const all = cueText.join(' ');
    // bracket tags like [Musik], each listed once (Set removes repeats)
    const tags = [...new Set(all.match(/\[[^\]]{1,40}\]/g) || [])];
    // the words, with bracket tags removed first
    const words = all.replace(/\[[^\]]{1,40}\]/g, ' ')
      .split(/\s+/).filter(Boolean);
    // words ending a sentence: . ! ? … maybe followed by a quote
    const sentenceEnds = words
      .filter((w) => /[.!?…]["»«“”)]*$/.test(w)).length;
    // words ending with , ; or :
    const commas = words.filter((w) => /[,;:]$/.test(w)).length;
    // the end time of every event, to find the video's length
    const ends = j.events.map((e) =>
      (e.tStartMs || 0) + (e.dDurationMs || 0));
    // add everything to the summary
    Object.assign(s, {
      // we did read json3
      format: 'json3',
      // number of lines with words
      cues: cues.length,
      // number of text pieces
      segs: segs.length,
      // pieces with their own start time
      segsWithWordOffset: segs.filter((g) => 'tOffsetMs' in g).length,
      // share of pieces that are timed; a line's first piece starts
      // with the line, so it counts as timed too
      wordTimingShare: segs.length
        ? Math.round(100 * (segs.filter((g) => 'tOffsetMs' in g).length
          + cues.length) / segs.length)
        : null,
      // line-break events of the rolling display
      appendEvents: j.events.filter((e) => e.aAppend).length,
      // length in minutes with two decimals (ms / 60000)
      durationMin: ends.length
        ? Math.round(Math.max(...ends) / 600) / 100 : 0,
      // number of words
      words: words.length,
      // number of sentence ends
      sentenceEnds,
      // number of commas and similar
      commas,
      // on average one sentence end every N words
      wordsPerSentenceEnd: sentenceEnds
        ? Math.round(words.length / sentenceEnds) : null,
      // guess: real text ends a sentence every 8–20 words,
      // raw speech recognition almost never
      looksPunctuated: words.length
        ? sentenceEnds / words.length > 0.02 : null,
      // the bracket tags found
      tags,
      // the first six lines as a sample
      sample: cueText.slice(0, 6),
      // the full file, for the Raw download
      raw: text,
    });
    // hand back the summary
    return s;
  }

  // Make the readable parts of an audio track's xtags visible.
  function decodeXtags(b64) {
    // try: bad input must not break anything
    try {
      // base64url uses - and _; atob wants + and /
      const bin = atob(b64.replace(/-/g, '+').replace(/_/g, '/'));
      // keep runs of 2+ printable characters, e.g. "acont" "original"
      return (bin.match(/[\x20-\x7e]{2,}/g) || []).join(' ');
      // not base64: give up quietly
    } catch (_) { return null; }
  }

  // Turn one player response into a summary.
  function summarisePlayer(pr, where) {
    // nothing to read
    if (!pr) return { where, missing: true };
    // the video's ID, title and so on
    const vd = pr.videoDetails || {};
    // extra metadata; the category lives here (not always present)
    const mf = (pr.microformat &&
      pr.microformat.playerMicroformatRenderer) || {};
    // the caption track list
    const tl = (pr.captions &&
      pr.captions.playerCaptionsTracklistRenderer) || {};
    // whether the video can play (and in an embed)
    const ps = pr.playabilityStatus || {};
    // each caption track, reduced to four fields
    const captionTracks = (tl.captionTracks || []).map((t) => ({
      // language code, e.g. "de"
      lang: t.languageCode,
      // "asr" for auto captions, otherwise manual
      kind: t.kind || 'manual',
      // track ID, e.g. "a.de" (auto) or ".de" (manual)
      vssId: t.vssId,
      // display name; YouTube gives either simpleText or runs
      name: t.name && (t.name.simpleText ||
        (t.name.runs || []).map((r) => r.text).join('')),
    }));
    // the audio tracks found
    const audioTracks = [];
    // track keys already listed (each audio track has many qualities)
    const seen = new Set();
    // all audio and video streams of the video
    const formats = (pr.streamingData &&
      pr.streamingData.adaptiveFormats) || [];
    // look at each stream
    for (const f of formats) {
      // skip video-only streams
      if (!f.audioTrack && !/^audio\//.test(f.mimeType || '')) continue;
      // a key per audio track (its id, else its xtags)
      const key = (f.audioTrack && f.audioTrack.id) || f.xtags || 'default';
      // already listed: skip
      if (seen.has(key)) continue;
      // remember it
      seen.add(key);
      // keep the name, default flag and decoded xtags
      audioTracks.push({
        // e.g. "en-US.4"
        id: f.audioTrack ? f.audioTrack.id : null,
        // e.g. "English (original)"
        displayName: f.audioTrack ? f.audioTrack.displayName : null,
        // the track that plays by default
        isDefault: f.audioTrack ? !!f.audioTrack.audioIsDefault : null,
        // e.g. "acont original lang en-US"
        xtags: f.xtags ? decodeXtags(f.xtags) : null,
      });
    }
    // the summary
    return {
      // where it came from (network or page variable)
      where,
      // the video ID
      videoId: vd.videoId || null,
      // the title
      title: vd.title || null,
      // the category, e.g. "Music", or null if missing
      category: mf.category || null,
      // "OK", "UNPLAYABLE", "ERROR", ...
      playability: ps.status || null,
      // true / false / null when YouTube didn't say
      playableInEmbed: ps.playableInEmbed ?? null,
      // the error text, if any
      reason: ps.reason || null,
      // the caption tracks
      captionTracks,
      // the audio tracks
      audioTracks,
      // embeds sometimes have no stream data
      hasStreamingData: !!pr.streamingData,
    };
  }

  // Called with every finished response we care about.
  function onResponse(url, status, text, via) {
    // try: a bug here must never break the player
    try {
      // captions: summarise and send
      if (isTimedText(url)) {
        post('timedtext', summariseTimedText(url, status, text, via));
        // player data: parse, summarise and send
      } else if (isPlayer(url)) {
        post('player', summarisePlayer(safeJson(text),
          'youtubei/v1/player (' + via + ')'));
      }
      // report the error instead of throwing it
    } catch (e) {
      post('error', { message: String((e && e.message) || e), where: via });
    }
  }

  // --- Wrapping XMLHttpRequest ---

  // Keep the original open method.
  const xhrOpen = XMLHttpRequest.prototype.open;
  // Keep the original send method.
  const xhrSend = XMLHttpRequest.prototype.send;

  // Replace open: remember the address, then call the original.
  XMLHttpRequest.prototype.open = function (method, url) {
    // turn a relative address into a full one and store it on the request
    try { this.__lsUrl = new URL(String(url), location.href).href; }
    // odd address: store it as it is
    catch (_) { this.__lsUrl = String(url); }
    // run the real open with the same arguments
    return xhrOpen.apply(this, arguments);
  };

  // Replace send: add a listener for interesting requests.
  XMLHttpRequest.prototype.send = function () {
    // the address stored by open
    const url = this.__lsUrl || '';
    // only captions and player data
    if (isTimedText(url) || isPlayer(url)) {
      // run when the response has fully arrived
      this.addEventListener('load', () => {
        // the body as text, if we can get it
        let text = null;
        // try: reading must not throw into YouTube's code
        try {
          // how the player asked for the body
          const rt = this.responseType;
          // plain text: read responseText
          if (rt === '' || rt === 'text') text = this.responseText;
          // already parsed JSON: turn back into text
          else if (rt === 'json') text = JSON.stringify(this.response);
          // raw bytes: decode as UTF-8
          else if (rt === 'arraybuffer') {
            text = new TextDecoder().decode(this.response);
          }
          // couldn't read it: leave text as null
        } catch (_) {}
        // summarise and send
        onResponse(url, this.status, text, 'xhr:' + (this.responseType || 'text'));
      });
    }
    // run the real send, so the request goes out as normal
    return xhrSend.apply(this, arguments);
  };

  // --- Wrapping fetch ---

  // Keep the original fetch.
  const origFetch = window.fetch;

  // Replace fetch with a wrapper.
  window.fetch = function (input, init) {
    // the address, whichever form it was given in
    let url = '';
    // input is a string, a URL object, or a Request with .url
    try {
      url = new URL(typeof input === 'string' || input instanceof URL
        ? String(input) : input.url, location.href).href;
      // unreadable: leave url empty
    } catch (_) {}
    // start the real request
    const p = origFetch.apply(this, arguments);
    // only captions and player data
    if (url && (isTimedText(url) || isPlayer(url))) {
      // when it arrives, read a CLONE (a body can be read only once)
      p.then((r) => r.clone().text()
        // then summarise it
        .then((t) => onResponse(url, r.status, t, 'fetch')))
        // ignore errors; the player handles its own
        .catch(() => {});
    }
    // give the player the original, untouched promise
    return p;
  };

  // --- Player data already in the page ---

  // Only read it once.
  let initialDone = false;

  // Look for player data YouTube put into the page itself.
  function readInitial() {
    // already done
    if (initialDone) return;
    // try: these variables may not exist
    try {
      // full page loads put it in this global variable
      if (window.ytInitialPlayerResponse) {
        // summarise and send
        post('player', summarisePlayer(window.ytInitialPlayerResponse,
          'ytInitialPlayerResponse'));
        // don't do it again
        initialDone = true;
      }
      // embeds keep their settings in YouTube's ytcfg object
      const pv = window.ytcfg && typeof window.ytcfg.get === 'function' &&
        window.ytcfg.get('PLAYER_VARS');
      // there, the player data is a JSON string
      if (pv && pv.embedded_player_response) {
        // parse, summarise and send
        post('player', summarisePlayer(safeJson(pv.embedded_player_response),
          'ytcfg PLAYER_VARS.embedded_player_response'));
        // don't do it again
        initialDone = true;
      }
      // report problems instead of throwing
    } catch (e) {
      post('error', { message: 'readInitial: ' + ((e && e.message) || e) });
    }
  }

  // Try when the HTML has been parsed...
  document.addEventListener('DOMContentLoaded', readInitial);
  // ...and again when everything has loaded.
  window.addEventListener('load', readInitial);
// End of the self-calling function; the () runs it.
})();
