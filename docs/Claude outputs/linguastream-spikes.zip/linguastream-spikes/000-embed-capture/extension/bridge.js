// bridge.js – runs in the ISOLATED world of the same frame.
// It receives the hook's messages and saves them to extension storage.

// The tag the hook puts on its messages.
const TAG = 'ls-spike-000';

// Listen for every message posted to this window.
window.addEventListener('message', (ev) => {
  // Ignore messages from other windows (e.g. a parent page)...
  if (ev.source !== window) return;
  // ...and messages without our tag.
  if (!ev.data || ev.data.source !== TAG) return;
  // Take the type ("timedtext", "player", ...) and the data.
  const { type, payload } = ev.data;
  // A unique ID: time in base 36 plus 5 random characters.
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  // The stored entry: id, type and all the data.
  const entry = { id, type, ...payload };
  // Everything to save in one go.
  const items = {};
  // A raw caption file is big: save it under its own key.
  if (typeof entry.raw === 'string') {
    // e.g. "raw:lq3x9a1b2c3"
    items['raw:' + id] = entry.raw;
    // note in the entry that a raw file exists
    entry.hasRaw = true;
  }
  // Remove the raw text from the entry itself.
  delete entry.raw;
  // The entry under its own key, e.g. "e:lq3x9a1b2c3".
  items['e:' + id] = entry;
  // Save both keys; separate keys mean frames can't overwrite each other.
  chrome.storage.local.set(items);
});
