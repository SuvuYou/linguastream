# Spike 000 – caption capture (youtube.com and embed)

Throwaway code for `docs/changes/000-embed-capture-spike/spec.md`. Not part of the app repository and not the production extension (D-039). Record results in `docs/changes/000-embed-capture-spike/results.md`.

## What it does
- `extension/hook.js` runs in YouTube's own page (MAIN world, every frame, at document start). It wraps `XMLHttpRequest` and `fetch` and **reads** responses the player requested itself: `/api/timedtext` (captions) and `/youtubei/v1/player` (track lists, category, audio tracks). It sends nothing, changes no request and never touches the player (rules 12–13). The `pot` token is never stored, only whether it was present.
- `extension/bridge.js` stores what the hook saw in the extension's local storage.
- The popup shows the results per check, lets you download each raw caption file, and copies a JSON report (without the raw files).
- `page/index.html` embeds a video on `http://localhost` with the variants from the spec.

## Setup (Opera or Chrome)
1. Open `opera://extensions` (or `chrome://extensions`), turn on **Developer mode**, **Load unpacked**, pick the `extension` folder. Pin the extension.
2. Disable Language Reactor and FluentAI for the test, so their hooks don't interfere.
3. Serve the test page: in the `page` folder run `npx serve -l 8080` (or `python -m http.server 8080`), then open `http://localhost:8080`.

## Runs
Use 3 German videos with **auto-generated** German captions, 1 with **manual** German captions, 1 with **AI-dubbed** audio tracks, and 1 that **forbids embedding**. Press **Clear** in the popup before each run.

| Run | Where | What to do | Checks |
|---|---|---|---|
| A | youtube.com watch page | Open a German video, turn on German CC | baseline for 2, 3, 5, 8, 9, 10 |
| B | test page, plain embed | Load the same video, click CC in the player | 1, 2, 3, 4a, 5 |
| C | test page, `cc_load_policy` ticked | Load it, do **not** click CC | 4b |
| D | test page, nocookie ticked | Load it, click CC | 7 |
| E | test page | Load the non-embeddable video | 6 |
| F | youtube.com | 2 more German auto-caption videos + the manual one | 8, 9 |
| G | youtube.com | Video with AI dubs: switch the audio track, then CC | 10 |

After each run: **Copy report** (or Download report) and keep it; for run A and F also click **Raw** on one caption row.

## Reading the popup
- **Frames:** an `iframe www.youtube.com/embed/... in http://localhost:8080` row = check 1 passes.
- **Caption responses:** `[ __ ]` is YouTube's censored-word tag. Format `json3`, cues/words, share of segments with word offsets (check 3; segments can hold several words, so compare segments to words), punctuation guess with sentence ends per words (check 8; a heuristic, confirm by reading the sample), bracket tags (check 9).
- **Player responses:** category (check 5), playability and `in embed` (check 6), caption tracks with `vssId` (`a.de` = auto), audio tracks with decoded `xtags` (`acont original` / `dubbed-auto`, check 10). "no streaming data" is normal in some embeds.
