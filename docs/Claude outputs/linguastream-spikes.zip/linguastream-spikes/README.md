# LinguaStream spikes

Throwaway experiments from phase 3 (D-062, D-083). Not the app, not the production extension (D-039). Specs and results live in the app repo under `docs/changes/NNN-*/`; open follow-ups in `docs/roadmap/spike-follow-ups.md`.

| Folder | Spike | Result |
|---|---|---|
| `000-embed-capture` | MV3 capture on youtube.com and in the embed | D-072 |
| `001-player-control` | Switching the German track on | D-074 |
| `002-punctuation` | Gemini punctuation + word alignment, join rule | D-077, D-078 |
| `003-extension-signin` | Firebase custom-token handoff to the extension | D-079 |
| `004-word-data` | (next) Wiktextract import, coverage, word packs | D-083 |

Reusable for the real build: `002-punctuation/src/align.ts` (`deriveEdits`, tests), `002-punctuation/src/extract.ts` (json3 → words, join rule), `000-embed-capture/extension/hook.js` (passive capture), `003-extension-signin` (handoff flow).

Never commit: `.env`, service-account keys, captured caption files (`input/`), `out/`. The `.gitignore` covers them.
