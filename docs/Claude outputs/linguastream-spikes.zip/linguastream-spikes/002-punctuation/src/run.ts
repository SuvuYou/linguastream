// run.ts – the spike's command line.
//   npm run inspect -- input/*.json            checks 1–2, no API calls
//   npm run punctuate -- --chunk 500 input/*.json
// Options: --chunk N (words per chunk, default 500), --overlap N (default 30),
//          --mode text|json (default text), --prompt basic|boundaries (default basic),
//          --no-retry, --mock (no API calls)
// Writes out/<video>.<chunk>.json (+ .txt), out/summary-<chunk>-<mode>.md and
// out/sample-<chunk>-<mode>.md (sentences to mark by hand, check 5).

import { basename, join } from 'node:path';
import { mkdirSync, writeFileSync, readFileSync, existsSync, statSync, readdirSync, globSync } from 'node:fs';
import { readJson3, extractTokens, punctuationStats, tagStats, ruleJoins, type Token } from './extract.ts';
import { deriveEdits, applyEdits, sentences, type Edit, type Change } from './align.ts';
import { punctuate, MODEL, type Mode, type Prompt } from './gemini.ts';
import { splitToken } from './align.ts';

const args = process.argv.slice(2);
const cmd = args.shift();
const opt = (name: string, def: string) => {
  const k = args.indexOf('--' + name);
  if (k < 0) return def;
  const v = args[k + 1];
  args.splice(k, 2);
  return v;
};
const flag = (name: string) => {
  const k = args.indexOf('--' + name);
  if (k < 0) return false;
  args.splice(k, 1);
  return true;
};
const CHUNK = Number(opt('chunk', '500'));
const OVERLAP = Number(opt('overlap', '30'));
const MODE = opt('mode', 'text') as Mode;
// --prompt basic|boundaries (boundaries: may move sentence ends, see gemini.ts)
const PROMPT = opt('prompt', 'basic') as Prompt;
// used in output file names: "text", "text-boundaries", ...
const TAG = MODE + (PROMPT === 'basic' ? '' : '-' + PROMPT);
// sentence-end changes per video, collected by runOne
const boundaryMoves: string[] = [];
const RETRY = !flag('no-retry');
// --mock: no API calls, a fake model (see gemini.ts) to try the pipeline.
if (flag('mock')) process.env.GEMINI_MOCK = '1';
// Files: names, folders (all .json inside) or patterns like input/*.json
// (expanded here, because Windows shells don't expand them).
const files = args.flatMap((a) => {
  if (existsSync(a) && statSync(a).isDirectory()) return readdirSync(a).filter((f) => f.endsWith('.json')).map((f) => join(a, f));
  if (a.includes('*')) return globSync(a);
  return [a];
});
// Prices per 1M tokens (check Google's pricing page and set them in .env).
const PRICE_IN = Number(process.env.PRICE_IN ?? '0.25');
const PRICE_OUT = Number(process.env.PRICE_OUT ?? '1.50');

mkdirSync('out', { recursive: true });
const name = (f: string) => basename(f).replace(/\.json3?\.json$|\.json$/, '');
const minutes = (t: Token[]) => (t.length ? Math.round(t.at(-1)!.startMs / 600) / 100 : 0);

if (cmd === 'inspect') inspect();
else if (cmd === 'captured') capturedSample();
else if (cmd === 'rule') ruleReport();
else if (cmd === 'punctuate') await runAll();
else console.log('usage: npm run inspect -- files… | npm run punctuate -- [--chunk N] [--overlap N] [--mode text|json] files…');

// Check 5 on YouTube's own punctuation: 10 sentences per video from the captured text.
function capturedSample() {
  const out = ['# Check 5 on the captured text (no LLM)\n\nTick = correct; otherwise note: wrong boundary / missing comma / wrong capital.\n'];
  for (const f of files) {
    const words = extractTokens(readJson3(f)).filter((t) => !t.tag).map((t) => t.text);
    const sents: string[] = [];
    let cur: string[] = [];
    for (const w of words) {
      cur.push(w);
      if (/[.!?…]["»«“”)]*$/.test(w)) { sents.push(cur.join(' ')); cur = []; }
    }
    const s = sents.filter((x) => x.split(' ').length > 3);
    const from = Math.max(0, Math.floor(s.length / 2) - 5);
    out.push(`\n## ${name(f)}\n` + s.slice(from, from + 10).map((x) => `- [ ] ${x}`).join('\n'));
  }
  writeFileSync('out/sample-captured.md', out.join('\n') + '\n');
  console.log(out.join('\n'));
}

// D-077 rule test: every join the rule would make, with context, and whether the
// LLM boundaries run (if present in out/) joined the same place.
function ruleReport() {
  const out = ['# Rule joins: full stop + lowercase word (D-077)\n\nTick = the join is right. "LLM" = the boundaries run joined the same place too.\n'];
  const totals: string[] = ['| Video | Rule joins | Also joined by the LLM | LLM joins the rule missed |', '|---|---|---|---|'];
  for (const f of files) {
    const words = extractTokens(readJson3(f)).filter((t) => !t.tag).map((t) => t.text);
    const joins = ruleJoins(words);
    // the LLM boundaries run, if it exists
    let llmJoined = new Set<number>();
    const llmFile = `out/${name(f)}.1000.text-boundaries.json`;
    if (existsSync(llmFile)) {
      const d = JSON.parse(readFileSync(llmFile, 'utf8')) as { words: string[]; punctuated: string };
      const shown = d.punctuated.split(' ');
      if (shown.length === d.words.length) {
        const end = (w: string) => /[.!?…]/.test(splitToken(w).after);
        d.words.forEach((w, k) => { if (end(w) && !end(shown[k])) llmJoined.add(k); });
      } else llmJoined = new Set([-1]);
    }
    const both = joins.filter((k) => llmJoined.has(k)).length;
    const missed = [...llmJoined].filter((k) => k >= 0 && !joins.includes(k)).length;
    totals.push(`| ${name(f)} | ${joins.length} | ${llmJoined.has(-1) ? 'n/a' : both} | ${llmJoined.has(-1) ? 'n/a' : missed} |`);
    out.push(`\n## ${name(f)} (${joins.length} joins)\n` + joins.map((k) => {
      const before = words.slice(Math.max(0, k - 8), k + 9).join(' ');
      const after = words.slice(Math.max(0, k - 8), k).concat(words[k].slice(0, -1), words.slice(k + 1, k + 9)).join(' ');
      return `- [ ] after "${words[k]}"${llmJoined.has(k) ? ' (LLM too)' : ''}\n  - before: ${before}\n  - after:  ${after}`;
    }).join('\n'));
  }
  const md = out[0] + '\n' + totals.join('\n') + '\n' + out.slice(1).join('\n') + '\n';
  writeFileSync('out/rule-joins.md', md);
  console.log(totals.join('\n'));
}

function inspect() {
  const rows = ['| Video | Min | Words | Sentence ends | 1 end per | Capital after end | Commas | Looks punctuated | Full stop + lowercase (rule joins) | Tags |', '|---|---|---|---|---|---|---|---|---|---|'];
  for (const f of files) {
    const t = extractTokens(readJson3(f));
    const s = punctuationStats(t);
    const joins = ruleJoins(t.filter((x) => !x.tag).map((x) => x.text)).length;
    const tags = Object.entries(tagStats(t)).map(([k, v]) => `${k}×${v}`).join(' ');
    rows.push(`| ${name(f)} | ${minutes(t)} | ${s.words} | ${s.sentenceEnds} | ${s.wordsPerSentenceEnd ?? '–'} | ${s.capitalAfterEnd ?? '–'}% | ${s.commas} | ${s.looksPunctuated ? 'yes' : 'no'} | ${joins} (${s.sentenceEnds ? Math.round((100 * joins) / s.sentenceEnds) : 0}% of ends) | ${tags} |`);
  }
  const md = '# Checks 1–2: captions as captured\n\n' + rows.join('\n') + '\n';
  writeFileSync('out/inspect.md', md);
  console.log(md);
}

interface ChunkReport {
  start: number; end: number; ok: boolean; retried: boolean;
  changes: Change[]; errors: string[]; tokensIn: number; tokensOut: number; tokensThinking: number; ms: number;
}

async function runAll() {
  const rows = ['| Video | Min | Words | Chunks | Edits per 100 words | Sentence ends before → after | Rejected 1st try | Rejected after retry | Changes (kinds) | API errors | Tokens in / out / thinking | Cost | Time |', '|---|---|---|---|---|---|---|---|---|---|---|---|---|'];
  const sample: string[] = [`# Check 5: mark each sentence\n\nChunk ${CHUNK}, overlap ${OVERLAP}, mode ${MODE}, prompt ${PROMPT}, model ${MODEL}. Tick = correct; otherwise note: wrong boundary / missing comma / wrong capital.\n`];
  let totIn = 0, totOut = 0, totMin = 0;
  for (const f of files) {
    const r = await runOne(f);
    const rej1 = r.chunks.filter((c) => !c.ok || c.retried).length;
    const rej2 = r.chunks.filter((c) => !c.ok).length;
    const kinds: Record<string, number> = {};
    for (const c of r.chunks) for (const ch of c.changes) kinds[ch.kind] = (kinds[ch.kind] ?? 0) + 1;
    const tin = sum(r.chunks.map((c) => c.tokensIn)), tout = sum(r.chunks.map((c) => c.tokensOut)), tthink = sum(r.chunks.map((c) => c.tokensThinking));
    const cost = (tin * PRICE_IN + (tout + tthink) * PRICE_OUT) / 1e6;
    totIn += tin; totOut += tout + tthink; totMin += r.min;
    rows.push(`| ${r.name} | ${r.min} | ${r.words} | ${r.chunks.length} | ${r.editsPer100} | ${r.endsBefore} → ${r.endsAfter} | ${rej1} | ${rej2} | ${Object.entries(kinds).map(([k, v]) => `${k} ${v}`).join(', ') || '–'} | ${sum(r.chunks.map((c) => c.errors.length))} | ${tin} / ${tout} / ${tthink} | $${cost.toFixed(4)} | ${(sum(r.chunks.map((c) => c.ms)) / 1000).toFixed(1)} s |`);
    // 10 sentences from the middle of the video, for manual marking
    const s = r.sentences.filter((x) => x.split(' ').length > 3);
    const from = Math.max(0, Math.floor(s.length / 2) - 5);
    sample.push(`\n## ${r.name}\n` + s.slice(from, from + 10).map((x) => `- [ ] ${x}`).join('\n'));
    // write after every video, so a stopped run still leaves its results
    writeSummary();
  }
  function writeSummary() {
  const perHour = totMin ? ((totIn * PRICE_IN + totOut * PRICE_OUT) / 1e6) * (60 / totMin) : 0;
  const md = `# Punctuation run: chunk ${CHUNK}, overlap ${OVERLAP}, mode ${MODE}, prompt ${PROMPT}\n\nModel ${MODEL}, prices $${PRICE_IN} / $${PRICE_OUT} per 1M tokens (in / out incl. thinking).\n\n` +
    rows.join('\n') + `\n\n**Cost per hour of video:** $${perHour.toFixed(4)} (over ${totMin.toFixed(1)} min).\n\nRejection details per chunk: \`out/<video>.${CHUNK}.${TAG}.json\`.\n`;
  writeFileSync(`out/summary-${CHUNK}-${TAG}.md`, md);
  writeFileSync(`out/sample-${CHUNK}-${TAG}.md`, sample.join('\n') + '\n');
  writeFileSync(`out/boundaries-${CHUNK}-${TAG}.md`, '# Sentence ends added or removed\n\nTick = the change is right.\n' + boundaryMoves.join('\n') + '\n');
  return md;
  }
  console.log(writeSummary());
}

async function runOne(file: string) {
  const tokens = extractTokens(readJson3(file));
  // Tags never go to the LLM; they keep their place in `tokens` (check 2).
  const words = tokens.filter((t) => !t.tag);
  const texts = words.map((t) => t.text);
  const edits: Edit[] = [];
  const chunks: ChunkReport[] = [];
  for (let start = 0; start < texts.length; start += CHUNK) {
    const end = Math.min(texts.length, start + CHUNK);
    // send overlap words on both sides for context; keep edits for [start, end) only
    const from = Math.max(0, start - OVERLAP), to = Math.min(texts.length, end + OVERLAP);
    const slice = texts.slice(from, to);
    const rep: ChunkReport = { start, end, ok: false, retried: false, changes: [], errors: [], tokensIn: 0, tokensOut: 0, tokensThinking: 0, ms: 0 };
    let note: string | undefined;
    for (let attempt = 0; attempt < (RETRY ? 2 : 1); attempt++) {
      let res;
      try {
        res = await punctuate(slice, MODE, note, PROMPT);
      } catch (e) {
        const msg = String((e as Error).message);
        rep.errors.push(msg.slice(0, 300));
        // 429 = rate limit (free tier): wait longer before the next try
        const wait = /429|RESOURCE_EXHAUSTED|quota/i.test(msg) ? 30000 : 5000;
        process.stdout.write(`  API error (${msg.slice(0, 120)}), waiting ${wait / 1000} s\n`);
        await sleep(wait);
        continue;
      }
      rep.tokensIn += res.tokensIn; rep.tokensOut += res.tokensOut; rep.tokensThinking += res.tokensThinking; rep.ms += res.ms;
      const d = deriveEdits(slice, res.text);
      if (d.ok) {
        for (const e of d.edits) {
          const gi = from + e.i;
          if (gi >= start && gi < end) edits.push({ ...e, i: gi });
        }
        rep.ok = true;
        rep.retried = attempt > 0;
        break;
      }
      rep.changes.push(...d.changes.map((c) => ('i' in c && c.i >= 0 ? { ...c, i: c.i + from } : c)));
      note = 'Achtung: In deiner letzten Antwort hast du Wörter geändert (' +
        d.changes.slice(0, 5).map((c) => c.kind === 'changed' ? `"${c.captured}" → "${c.returned}"` : c.kind === 'dropped' ? `"${c.captured}" weggelassen` : `"${c.returned}" hinzugefügt`).join(', ') +
        '). Ändere diesmal kein einziges Wort.';
    }
    chunks.push(rep);
    process.stdout.write(`${name(file)} words ${start}–${end}: ${rep.ok ? (rep.retried ? 'ok after retry' : 'ok') : rep.errors.length && !rep.changes.length ? 'API ERROR: ' + rep.errors[0] : 'REJECTED'}\n`);
  }
  const shown = applyEdits(texts, edits);
  const sents = sentences(shown, edits);
  const out = { video: name(file), model: MODEL, chunk: CHUNK, overlap: OVERLAP, mode: MODE, prompt: PROMPT, words: texts, edits, chunks, punctuated: shown.join(' ') };
  writeFileSync(`out/${name(file)}.${CHUNK}.${TAG}.json`, JSON.stringify(out, null, 1));
  writeFileSync(`out/${name(file)}.${CHUNK}.${TAG}.txt`, sents.join('\n') + '\n');
  // how much the model changed: punctuation/case edits per 100 words (sentence-end marks alone don't count)
  const changed = edits.filter((e) => e.before !== undefined || e.after !== undefined || e.casing !== undefined).length;
  // Every place where a sentence end was added or removed, with context, to mark by hand.
  const isEnd = (w: string) => /[.!?…]/.test(splitToken(w).after);
  const moves: string[] = [];
  let endsBefore = 0, endsAfter = 0;
  for (let k = 0; k < texts.length; k++) {
    const b = isEnd(texts[k]), a = isEnd(shown[k]);
    if (b) endsBefore++;
    if (a) endsAfter++;
    if (a === b) continue;
    const ctx = (ws: string[]) => ws.slice(Math.max(0, k - 8), k + 9).join(' ');
    moves.push(`- [ ] **${a ? 'split' : 'joined'}** after "${texts[k]}"\n  - before: ${ctx(texts)}\n  - after:  ${ctx(shown)}`);
  }
  boundaryMoves.push(`\n## ${name(file)} (${moves.length} changes)\n` + moves.join('\n'));
  return { name: name(file), min: minutes(tokens), words: texts.length, chunks, sentences: sents, endsBefore, endsAfter, editsPer100: texts.length ? Math.round((1000 * changed) / texts.length) / 10 : 0 };
}

function sum(a: number[]) { return a.reduce((x, y) => x + y, 0); }
function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
