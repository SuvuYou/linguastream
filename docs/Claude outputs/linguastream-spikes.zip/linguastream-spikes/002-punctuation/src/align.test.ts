// Tests for deriveEdits (the Block A exercise). Run: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { deriveEdits, applyEdits, splitToken } from './align.ts';
import { ruleJoins } from './extract.ts';

const cap = 'ich weiß nicht ob das geht aber wir versuchen es'.split(' ');

test('accepts punctuation and capitals only', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Aber wir versuchen es.');
  assert.equal(r.ok, true);
  if (!r.ok) return;
  assert.deepEqual(applyEdits(cap, r.edits).join(' '), 'Ich weiß nicht, ob das geht. Aber wir versuchen es.');
  assert.deepEqual(r.edits.filter((e) => e.sentenceEnd).map((e) => e.i), [5, 9]);
});

test('rejects a changed word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das klappt. Aber wir versuchen es.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'changed', i: 5, captured: 'geht', returned: 'klappt.' }]);
});

test('rejects a dropped word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Wir versuchen es.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'dropped', i: 6, captured: 'aber' }]);
});

test('rejects an added word', () => {
  const r = deriveEdits(cap, 'Ich weiß nicht, ob das geht. Aber wir versuchen es doch.');
  assert.equal(r.ok, false);
  if (r.ok) return;
  assert.deepEqual(r.changes, [{ kind: 'added', afterI: 9, returned: 'doch.' }]);
});

test('glues a free-standing dash to the previous word', () => {
  const r = deriveEdits(['das', 'ist', 'gut'], 'Das ist – gut.');
  assert.equal(r.ok, true);
});

test('handles already punctuated captions', () => {
  const r = deriveEdits(['Hallo,', 'wie', 'geht’s?'], 'Hallo, wie geht’s?');
  assert.equal(r.ok, true);
  // nothing to change, but the sentence end is still recorded
  if (r.ok) assert.deepEqual(r.edits, [{ i: 2, sentenceEnd: true }]);
});

test('splitToken', () => {
  assert.deepEqual(splitToken('„Hallo,'), { before: '„', core: 'Hallo', after: ',' });
  assert.deepEqual(splitToken('geht’s?'), { before: '', core: 'geht’s', after: '?' });
});

test('ignores captured tokens that are only punctuation (speaker dashes)', () => {
  const c = ['-', 'Kommst', 'du?', '-', 'Ja,', 'gleich.'];
  const r = deriveEdits(c, '– Kommst du? – Ja, gleich.');
  assert.equal(r.ok, true);
  const r2 = deriveEdits(c, 'Kommst du? Ja, gleich.');
  assert.equal(r2.ok, true);
  if (r2.ok) assert.deepEqual(r2.edits.map((e) => e.i), [2, 5]);
  const r3 = deriveEdits(c, 'Kommst du? Nein, gleich.');
  assert.equal(r3.ok, false);
  if (!r3.ok) assert.deepEqual(r3.changes, [{ kind: 'changed', i: 4, captured: 'Ja,', returned: 'Nein,' }]);
});

test('treats >> speaker marks as punctuation', () => {
  const r = deriveEdits(['>>', 'yeah', 'right'], 'Yeah, right.');
  assert.equal(r.ok, true);
  assert.equal(deriveEdits(['>>', 'yeah'], '>> Yeah.').ok, true);
});

test('rule joins: full stop + lowercase word, but not abbreviations, ordinals, ellipses or brands', () => {
  const w = 'Wir haben Flugzeuge. wir haben z.B. viele am 17. september ich... und dann. iPhone Ja. und gucken.'.split(' ');
  assert.deepEqual(ruleJoins(w).map((k) => w[k]), ['Flugzeuge.', 'Ja.']);
});
