// gemini.ts – one call: German words in, punctuated text out.

import { GoogleGenAI, ThinkingLevel } from '@google/genai';

export const MODEL = process.env.GEMINI_MODEL ?? 'gemini-3.1-flash-lite';
// Gemini 3 models think by default; "minimal" is the no-thinking setting.
const THINKING = (process.env.THINKING_LEVEL ?? 'MINIMAL').toUpperCase() as ThinkingLevel;

let client: GoogleGenAI | null = null;
function ai() {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing: put it in .env');
  return (client ??= new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }));
}

export type Mode = 'text' | 'json';

export const SYSTEM = `Du bekommst automatisch erzeugte deutsche Untertitel ohne zuverlässige Zeichensetzung.
Setze Satzzeichen (. , ? ! : ; – „ “) und korrigiere Groß- und Kleinschreibung.
Strenge Regeln:
- Ändere kein Wort. Keine Rechtschreibkorrektur, keine Zahlen als Ziffern, keine Abkürzungen ausschreiben.
- Füge kein Wort hinzu und lass kein Wort weg, auch keine Füllwörter wie "äh" oder "halt".
- Behalte die Reihenfolge der Wörter genau bei.
- Gib nur den Text zurück, ohne Erklärung.`;

// --prompt boundaries: the same rules, plus permission to move sentence ends.
export const SYSTEM_BOUNDARIES = `Du bekommst automatisch erzeugte deutsche Untertitel. Die Zeichensetzung ist schon da, aber oft falsch: Sätze enden mitten im Gedanken, oder mehrere Sätze laufen ohne Punkt ineinander.
Verbessere Satzzeichen (. , ? ! : ; – „ “) und Groß- und Kleinschreibung:
- Ein Satz darf über einen vorhandenen Punkt hinweggehen: Verbinde fälschlich getrennte Sätze (Punkt entfernen, nächstes Wort klein schreiben, wenn es kein Nomen ist).
- Teile zu lange, ineinanderlaufende Sätze an den richtigen Stellen.
- Setze fehlende Kommas, besonders vor Nebensätzen und zwischen Hauptsätzen.
Strenge Regeln:
- Ändere kein Wort, auch wenn es falsch gehört oder falsch geschrieben scheint. Keine Zahlen als Ziffern, keine Abkürzungen ausschreiben.
- Füge kein Wort hinzu und lass kein Wort weg, auch keine Füllwörter wie "äh" oder "halt".
- Behalte die Reihenfolge der Wörter genau bei.
- Gib nur den Text zurück, ohne Erklärung.`;

export type Prompt = 'basic' | 'boundaries';

export interface CallResult {
  text: string;
  tokensIn: number;
  tokensOut: number;
  tokensThinking: number;
  ms: number;
}

export async function punctuate(words: string[], mode: Mode, retryNote?: string, prompt: Prompt = 'basic'): Promise<CallResult> {
  // Dry run without an API key (--mock): puts a full stop every 12 words and
  // changes one word on the first try, so the retry path runs too.
  if (process.env.GEMINI_MOCK === '1') return mock(words, retryNote);
  const input = words.join(' ');
  const user = (retryNote ? retryNote + '\n\n' : '') +
    (mode === 'json' ? 'Antworte als JSON {"text": "..."}.\n\n' : '') + input;
  const t0 = Date.now();
  const r = await ai().models.generateContent({
    model: MODEL,
    contents: user,
    config: {
      systemInstruction: prompt === 'boundaries' ? SYSTEM_BOUNDARIES : SYSTEM,
      temperature: 0,
      thinkingConfig: { thinkingLevel: THINKING },
      // A call never hangs: give up after TIMEOUT_S seconds (default 90), and let
      // run.ts handle retries instead of the SDK retrying quietly.
      httpOptions: { timeout: Number(process.env.TIMEOUT_S ?? '90') * 1000, retryOptions: { attempts: 1 } },
      ...(mode === 'json'
        ? {
            responseMimeType: 'application/json',
            responseSchema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
          }
        : {}),
    },
  });
  const raw = r.text ?? '';
  const text = mode === 'json' ? (JSON.parse(raw) as { text: string }).text : raw.trim();
  const u = r.usageMetadata ?? {};
  return {
    text,
    tokensIn: u.promptTokenCount ?? 0,
    tokensOut: u.candidatesTokenCount ?? 0,
    tokensThinking: u.thoughtsTokenCount ?? 0,
    ms: Date.now() - t0,
  };
}

function mock(words: string[], retryNote?: string): CallResult {
  const out = words.map((w, k) => {
    let x = k === 0 || k % 12 === 0 ? w.charAt(0).toUpperCase() + w.slice(1) : w;
    if ((k + 1) % 12 === 0) x += '.';
    return x;
  });
  if (!retryNote && out.length > 5) out[5] = 'CHANGED';
  return { text: out.join(' '), tokensIn: words.length * 2, tokensOut: words.length * 2, tokensThinking: 0, ms: 1 };
}
